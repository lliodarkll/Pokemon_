"""Ponto de entrada: bot de fichas genéricas + módulo Pokémon.

Local:      DISCORD_TOKEN=seu_token python main.py
Hospedagem: coloque DISCORD_TOKEN=... no arquivo bot.env (ao lado deste arquivo).
"""
import os

# Garante que fichas.db, pokemon.db e art_cache/ fiquem sempre ao lado deste arquivo,
# não importa de onde a hospedagem execute o bot.
HERE = os.path.dirname(os.path.abspath(__file__))
os.chdir(HERE)


def load_env_file():
    """Lê bot.env (ou .env) se existir; variáveis já definidas no sistema têm prioridade."""
    for name in ("bot.env", ".env"):
        path = os.path.join(HERE, name)
        if not os.path.isfile(path):
            continue
        with open(path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, value = line.split("=", 1)
                os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


load_env_file()

import logging  # noqa: E402

from bot_fichas import bot  # noqa: E402  (bot base e /rolar)
from pokebot.commands import register  # noqa: E402
from pokebot.ficha_cmds import register as register_ficha  # noqa: E402

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s: %(message)s")
mod = register(bot.tree)  # adiciona /pokémon e /pokédex
migradas = mod.store.migrate_old_fichas("fichas.db")  # copia as fichas antigas (uma única vez)
if migradas:
    logging.getLogger("pokebot").info("%d ficha(s) antiga(s) migrada(s) para o formato novo", migradas)
register_ficha(bot.tree, mod.store)  # adiciona /ficha e /for /des /vig /int /sin /afi

if __name__ == "__main__":
    token = os.getenv("DISCORD_TOKEN", "").strip()
    if not token or "COLE" in token:
        raise SystemExit("Token ausente: defina DISCORD_TOKEN (ou preencha o arquivo bot.env).")
    bot.run(token)
