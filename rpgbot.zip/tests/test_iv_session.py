import random
import unittest

from pokebot.calculator import STATS
from pokebot.iv_session import (
    SessionError, assign, empty_assignment, next_open_stat, parse_dice, roll_ivs,
    unassigned_rolls, validate_complete, validate_dice_for_ivs,
)

ROLLS = [3, 14, 10, 30, 15, 23]


class Dice(unittest.TestCase):
    def test_default_range(self):
        spec = parse_dice("1d32-1")
        self.assertEqual((spec.minimum, spec.maximum), (0, 31))
        validate_dice_for_ivs(spec)

    def test_rolls_always_valid(self):
        rng = random.Random(1)
        for _ in range(500):
            rolls = roll_ivs("1d32-1", rng=rng)
            self.assertEqual(len(rolls), 6)
            self.assertTrue(all(0 <= r <= 31 for r in rolls))

    def test_rejects_dangerous_or_bad_expressions(self):
        for expr in ("1d32", "2d20", "1d20-5", "abc", "d20", "0d6", "1d1"):
            with self.assertRaises(SessionError, msg=expr):
                roll_ivs(expr)

    def test_other_valid_expression(self):
        self.assertEqual(parse_dice("2d16-2").text, "2d16-2")
        validate_dice_for_ivs(parse_dice("2d16-2"))  # 0..30


class Assignment(unittest.TestCase):
    def full(self):
        a = empty_assignment()
        for i, s in enumerate(STATS):
            a = assign(a, s, i, 6)
        return a

    def test_complete_in_any_order(self):
        a = empty_assignment()
        for s, i in zip(STATS, [5, 3, 1, 0, 2, 4]):
            a = assign(a, s, i, 6)
        ivs = validate_complete(ROLLS, a)
        self.assertEqual(ivs["hp"], 23)
        self.assertEqual(ivs["attack"], 30)
        self.assertEqual(sorted(ivs.values()), sorted(ROLLS))

    def test_duplicate_blocked(self):
        a = assign(empty_assignment(), "hp", 2, 6)
        with self.assertRaises(SessionError):
            assign(a, "attack", 2, 6)

    def test_reassign_releases_old_roll(self):
        a = assign(empty_assignment(), "hp", 2, 6)
        a = assign(a, "hp", 4, 6)
        self.assertIn(2, unassigned_rolls(a, 6))
        a = assign(a, "attack", 2, 6)  # agora livre
        self.assertEqual(a["attack"], 2)

    def test_same_value_rolls_are_distinct(self):
        rolls = [10, 10, 10, 10, 10, 10]
        a = self.full()
        self.assertEqual(set(validate_complete(rolls, a).values()), {10})

    def test_invalid_inputs(self):
        with self.assertRaises(SessionError):
            assign(empty_assignment(), "luck", 0, 6)
        for bad in (-1, 6, "1", None):
            with self.assertRaises(SessionError):
                assign(empty_assignment(), "hp", bad, 6)

    def test_incomplete_blocked(self):
        a = assign(empty_assignment(), "hp", 0, 6)
        with self.assertRaises(SessionError):
            validate_complete(ROLLS, a)
        with self.assertRaises(SessionError):
            validate_complete(ROLLS, empty_assignment())

    def test_tampered_assignment_blocked(self):
        a = self.full()
        a["speed"] = a["hp"]  # duplicado forjado
        with self.assertRaises(SessionError):
            validate_complete(ROLLS, a)
        a = self.full()
        a["speed"] = 99
        with self.assertRaises(SessionError):
            validate_complete(ROLLS, a)

    def test_out_of_range_roll_values_blocked(self):
        with self.assertRaises(Exception):
            validate_complete([3, 14, 10, 30, 15, 99], self.full())

    def test_next_open_stat(self):
        self.assertEqual(next_open_stat(empty_assignment()), "hp")
        self.assertIsNone(next_open_stat(self.full()))
