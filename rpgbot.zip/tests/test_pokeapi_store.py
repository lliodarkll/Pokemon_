import asyncio
import unittest

from pokebot.calculator import calculate_stats, zero_evs
from pokebot.iv_session import assign, empty_assignment, validate_complete
from pokebot.pokeapi import (
    ApiUnavailable, PokeApiClient, PokeApiError, SpeciesNotFound, normalize_name, parse_pokemon,
)
from pokebot.store import Store, StoreError


def _stat(name, value):
    return {"base_stat": value, "stat": {"name": name}}


LITWICK = {
    "id": 607, "name": "litwick",
    "species": {"name": "litwick", "url": "https://pokeapi.co/api/v2/pokemon-species/607/"},
    "stats": [_stat("hp", 50), _stat("attack", 30), _stat("defense", 55),
              _stat("special-attack", 65), _stat("special-defense", 55), _stat("speed", 20)],
    "types": [{"slot": 2, "type": {"name": "fire"}}, {"slot": 1, "type": {"name": "ghost"}}],
    "sprites": {"front_default": "https://x/f.png",
                "other": {"official-artwork": {"front_default": "https://x/art.png"}}},
}


def run(coro):
    return asyncio.run(coro)


class Parsing(unittest.TestCase):
    def test_parse(self):
        sp = parse_pokemon(LITWICK)
        self.assertEqual((sp.display_name, sp.dex), ("Litwick", 607))
        self.assertEqual(sp.types, ["ghost", "fire"])  # ordenado por slot
        self.assertEqual(sp.artwork, "https://x/art.png")
        self.assertEqual(sp.base["special_attack"], 65)

    def test_parse_malformed(self):
        with self.assertRaises(PokeApiError):
            parse_pokemon({"name": "x"})
        broken = {**LITWICK, "stats": LITWICK["stats"][:5]}
        with self.assertRaises(PokeApiError):
            parse_pokemon(broken)

    def test_normalize(self):
        self.assertEqual(normalize_name(" Mr. Mime "), "mr-mime")
        self.assertEqual(normalize_name("Nidoran♀"), "nidoran-f")
        self.assertEqual(normalize_name("Farfetch'd"), "farfetchd")
        self.assertEqual(normalize_name("Vulpix Alola"), "vulpix-alola")


class Client(unittest.TestCase):
    def make(self, store=None):
        calls = []

        async def fetch(url):
            calls.append(url)
            if url.endswith("/pokemon/litwick") or url.endswith("/pokemon/607"):
                return LITWICK
            raise SpeciesNotFound(url)

        return PokeApiClient(store, fetch_json=fetch, retry_delay=0), calls

    def test_found_and_cached(self):
        client, calls = self.make(Store(":memory:"))
        run(client.get_species("Litwick"))
        run(client.get_species("litwick"))
        self.assertEqual(len(calls), 1)

    def test_sqlite_cache_survives_new_client(self):
        store = Store(":memory:")
        c1, _ = self.make(store)
        run(c1.get_species("litwick"))
        c2, calls2 = self.make(store)
        sp = run(c2.get_species("litwick"))
        self.assertEqual(calls2, [])
        self.assertEqual(sp.base["hp"], 50)

    def test_invalid_names(self):
        client, _ = self.make()
        for bad in ("pokemonquenaoexiste", "", "   "):
            with self.assertRaises(SpeciesNotFound):
                run(client.get_species(bad))

    def test_network_failure_retries_then_raises(self):
        calls = []

        async def down(url):
            calls.append(url)
            raise ApiUnavailable("fora do ar")

        client = PokeApiClient(fetch_json=down, retries=3, retry_delay=0)
        with self.assertRaises(ApiUnavailable):
            run(client.get_species("litwick"))
        self.assertEqual(len(calls), 3)

    def test_recovers_after_transient_failure(self):
        state = {"n": 0}

        async def flaky(url):
            state["n"] += 1
            if state["n"] == 1:
                raise ApiUnavailable("falha momentânea")
            return LITWICK

        sp = run(PokeApiClient(fetch_json=flaky, retry_delay=0).get_species("litwick"))
        self.assertEqual(sp.identifier, "litwick")

    def test_list_names(self):
        async def fetch(url):
            return {"results": [{"name": "litwick"}, {"name": "vulpix-alola"}]}

        names = run(PokeApiClient(fetch_json=fetch).list_names())
        self.assertEqual(names, ["litwick", "vulpix-alola"])


class FullFlow(unittest.TestCase):
    ROLLS = [3, 14, 10, 30, 15, 23]

    def test_session_to_sheet_data(self):
        store = Store(":memory:")
        sp = parse_pokemon(LITWICK).to_dict()
        sid = store.create_session(1, 42, sp, 5, self.ROLLS)

        a = empty_assignment()
        for stat, idx in zip(["hp", "attack", "defense", "special_attack", "special_defense", "speed"],
                             range(6)):
            a = assign(a, stat, idx, 6)
        store.save_session(sid, a, None)

        sess = store.get_pending_session(1, 42)  # recuperável após reinício
        self.assertEqual(sess["id"], sid)
        ivs = validate_complete(sess["rolls"], sess["assignment"])
        pid = store.finalize_session(sid, ivs)

        poke = store.get_pokemon(1, pid)
        stats = calculate_stats(poke["species"]["base"], poke["ivs"], poke["evs"], poke["level"], poke["nature"])
        self.assertEqual(stats, dict(hp=20, attack=8, defense=11, special_attack=13,
                                     special_defense=11, speed=8))
        self.assertEqual(poke["owner_id"], 42)
        self.assertIsNone(store.get_pending_session(1, 42))

    def test_finalize_twice_blocked(self):
        store = Store(":memory:")
        sid = store.create_session(1, 42, parse_pokemon(LITWICK).to_dict(), 5, self.ROLLS)
        ivs = dict(zip(["hp", "attack", "defense", "special_attack", "special_defense", "speed"], self.ROLLS))
        store.finalize_session(sid, ivs)
        with self.assertRaises(StoreError):
            store.finalize_session(sid, ivs)
        self.assertEqual(len(store.list_pokemon(1)), 1)

    def test_update_keeps_ivs_and_guild_isolation(self):
        store = Store(":memory:")
        sid = store.create_session(1, 42, parse_pokemon(LITWICK).to_dict(), 5, self.ROLLS)
        ivs = dict(zip(["hp", "attack", "defense", "special_attack", "special_defense", "speed"], self.ROLLS))
        pid = store.finalize_session(sid, ivs)
        store.update_pokemon(1, pid, level=50, nature="Adamant", evs={**zero_evs(), "hp": 4})
        p = store.get_pokemon(1, pid)
        self.assertEqual((p["level"], p["nature"], p["ivs"]), (50, "Adamant", ivs))
        self.assertIsNone(store.get_pokemon(2, pid))  # outro servidor não enxerga
        with self.assertRaises(StoreError):
            store.update_pokemon(1, pid, owner_id=99)  # campo não editável

    def test_settings(self):
        store = Store(":memory:")
        self.assertEqual(store.get_setting(1, "dice", "1d32-1"), "1d32-1")
        store.set_setting(1, "dice", "2d16-2")
        store.set_setting(1, "dice", "2d16-1")
        self.assertEqual(store.get_setting(1, "dice"), "2d16-1")


if __name__ == "__main__":
    unittest.main()
