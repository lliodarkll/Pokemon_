import asyncio
import io
import shutil
import tempfile
import unittest

from pokebot.pokeapi import (
    Evolution, PokeApiClient, PokeApiError, SpeciesNotFound, available_evolutions,
    newly_ready, parse_evolutions, parse_pokemon,
)
from pokebot.store import Store
from tests.test_pokeapi_store import LITWICK


def detail(trigger="level-up", **kw):
    d = {"gender": None, "held_item": None, "item": None, "known_move": None, "known_move_type": None,
         "location": None, "min_affection": None, "min_beauty": None, "min_happiness": None,
         "min_level": None, "needs_overworld_rain": False, "party_species": None, "party_type": None,
         "relative_physical_stats": None, "time_of_day": "", "trade_species": None,
         "turn_upside_down": False, "trigger": {"name": trigger}}
    d.update(kw)
    return d


def node(name, details=(), children=()):
    return {"species": {"name": name}, "evolution_details": list(details), "evolves_to": list(children)}


LITWICK_CHAIN = node("litwick", [], [
    node("lampent", [detail(min_level=41)], [
        node("chandelure", [detail("use-item", item={"name": "dusk-stone"})]),
    ]),
])
EEVEE_CHAIN = node("eevee", [], [
    node("vaporeon", [detail("use-item", item={"name": "water-stone"})]),
    node("umbreon", [detail(min_happiness=160, time_of_day="night")]),
    node("leafeon", [detail(min_level=20, location={"name": "eterna-forest"}), detail("use-item", item={"name": "leaf-stone"})]),
])
WURMPLE_CHAIN = node("wurmple", [], [
    node("silcoon", [detail(min_level=7)]),
    node("cascoon", [detail(min_level=7)]),
])


class Parsing(unittest.TestCase):
    def test_level_evolution(self):
        (e,) = parse_evolutions(LITWICK_CHAIN, "litwick")
        self.assertEqual((e.target, e.min_level, e.plain_level, e.requirement), ("lampent", 41, True, "Nv. 41"))

    def test_item_evolution_is_not_plain(self):
        (e,) = parse_evolutions(LITWICK_CHAIN, "lampent")
        self.assertEqual(e.target, "chandelure")
        self.assertFalse(e.plain_level)
        self.assertEqual(e.requirement, "Dusk Stone")

    def test_final_form_and_unknown(self):
        self.assertEqual(parse_evolutions(LITWICK_CHAIN, "chandelure"), [])
        self.assertEqual(parse_evolutions(LITWICK_CHAIN, "inexistente"), [])

    def test_branching_and_conditions(self):
        evos = {e.target: e for e in parse_evolutions(EEVEE_CHAIN, "eevee")}
        self.assertEqual(len(evos), 3)
        self.assertFalse(evos["umbreon"].plain_level)
        self.assertIn("amizade", evos["umbreon"].requirement)
        self.assertIn("de noite", evos["umbreon"].requirement)
        self.assertFalse(evos["leafeon"].plain_level)  # nível + local não é "puro"

    def test_two_level_branches(self):
        evos = parse_evolutions(WURMPLE_CHAIN, "wurmple")
        self.assertEqual([e.target for e in evos], ["silcoon", "cascoon"])
        self.assertTrue(all(e.plain_level and e.min_level == 7 for e in evos))

    def test_malformed(self):
        with self.assertRaises(PokeApiError):
            parse_evolutions({"nada": 1}, "litwick")


class Availability(unittest.TestCase):
    def setUp(self):
        self.lampent = Evolution("lampent", 41, True, "Nv. 41")
        self.stone = Evolution("chandelure", None, False, "Dusk Stone")

    def test_level_gate(self):
        self.assertEqual(available_evolutions([self.lampent], 40), [])
        self.assertEqual(available_evolutions([self.lampent], 41), [self.lampent])
        self.assertEqual(available_evolutions([self.lampent], 100), [self.lampent])

    def test_non_level_needs_admin(self):
        self.assertEqual(available_evolutions([self.stone], 100, admin=False), [])
        self.assertEqual(available_evolutions([self.stone], 1, admin=True), [self.stone])

    def test_newly_ready_only_when_crossing(self):
        self.assertEqual(newly_ready([self.lampent, self.stone], 40, 41), [self.lampent])
        self.assertEqual(newly_ready([self.lampent], 41, 50), [])   # já tinha cruzado
        self.assertEqual(newly_ready([self.lampent], 10, 100), [self.lampent])
        self.assertEqual(newly_ready([self.lampent], 50, 30), [])   # nível baixou
        self.assertEqual(newly_ready([self.stone], 1, 100), [])


class Client(unittest.TestCase):
    def make(self, store=None):
        calls = []
        sd = {"evolution_chain": {"url": "https://pokeapi.co/api/v2/evolution-chain/1/"}}

        async def fetch(url):
            calls.append(url)
            if url.endswith("/pokemon-species/litwick"):
                return sd
            if url.endswith("/evolution-chain/1/"):
                return {"chain": LITWICK_CHAIN}
            if url.endswith("/pokemon-species/solo"):
                return {"evolution_chain": None}
            if url.endswith("/pokemon-species/wormadam"):
                return {"varieties": [{"is_default": False, "pokemon": {"name": "x"}},
                                      {"is_default": True, "pokemon": {"name": "litwick"}}]}
            if url.endswith("/pokemon/litwick"):
                return LITWICK
            raise SpeciesNotFound(url)

        return PokeApiClient(store, fetch_json=fetch, retry_delay=0), calls

    def test_get_evolutions_and_cache(self):
        store = Store(":memory:")
        client, calls = self.make(store)
        sp = parse_pokemon(LITWICK)
        evos = asyncio.run(client.get_evolutions(sp))
        self.assertEqual([e.target for e in evos], ["lampent"])
        n = len(calls)
        client2, calls2 = self.make(store)
        asyncio.run(client2.get_evolutions(sp))
        self.assertEqual(calls2, [])  # veio do cache SQLite
        self.assertEqual(n, 2)

    def test_species_without_chain(self):
        client, _ = self.make()
        sp = parse_pokemon({**LITWICK, "name": "solo", "species": {"name": "solo", "url": ""}})
        self.assertEqual(asyncio.run(client.get_evolutions(sp)), [])

    def test_default_variety_fallback(self):
        client, _ = self.make()
        sp = asyncio.run(client.get_species("wormadam"))
        self.assertEqual(sp.identifier, "litwick")
        with self.assertRaises(SpeciesNotFound):
            asyncio.run(client.get_species("naoexiste"))

    def test_image_cache_on_disk(self):
        tmp = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, tmp, True)
        n = {"c": 0}

        async def fb(url):
            n["c"] += 1
            return b"PNGDATA"

        client = PokeApiClient(fetch_bytes=fb, image_dir=tmp)
        self.assertEqual(asyncio.run(client.get_image("https://x/a.png")), b"PNGDATA")
        self.assertEqual(asyncio.run(client.get_image("https://x/a.png")), b"PNGDATA")
        self.assertEqual(n["c"], 1)


try:
    from PIL import Image, ImageDraw
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


@unittest.skipUnless(HAS_PIL, "Pillow não instalado")
class Gif(unittest.TestCase):
    @staticmethod
    def sprite(color, box, size=(475, 475)):
        im = Image.new("RGBA", size, (0, 0, 0, 0))
        ImageDraw.Draw(im).ellipse(box, fill=color)
        b = io.BytesIO()
        im.save(b, "PNG")
        return b.getvalue()

    def test_renders_valid_animated_gif(self):
        from pokebot.evolution_gif import render_evolution_gif
        old = self.sprite((230, 230, 190, 255), (150, 150, 330, 420))
        new = self.sprite((140, 90, 200, 255), (90, 90, 400, 450), (600, 500))  # tamanho diferente
        gif = render_evolution_gif(old, new, accent=(115, 87, 151))
        g = Image.open(io.BytesIO(gif))
        self.assertEqual(g.format, "GIF")
        self.assertGreater(g.n_frames, 30)
        self.assertEqual(g.size, (320, 320))
        self.assertLess(len(gif), 4_000_000)  # cabe com folga no limite de upload do Discord

    def test_rejects_empty_image(self):
        from pokebot.evolution_gif import render_evolution_gif
        empty = self.sprite((0, 0, 0, 0), (0, 0, 1, 1))
        ok = self.sprite((230, 230, 190, 255), (150, 150, 330, 420))
        with self.assertRaises(ValueError):
            render_evolution_gif(empty, ok)
        with self.assertRaises(Exception):
            render_evolution_gif(b"nao e imagem", ok)


if __name__ == "__main__":
    unittest.main()
