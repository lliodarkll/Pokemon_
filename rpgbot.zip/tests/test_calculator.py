import unittest

from pokebot.calculator import (
    STATS, CalcError, Ruleset, calculate_stats, canonical_nature, nature_label, zero_evs,
)

BASE = dict(hp=50, attack=30, defense=55, special_attack=65, special_defense=55, speed=20)  # Litwick
IVS = dict(hp=3, attack=14, defense=10, special_attack=30, special_defense=15, speed=23)


def calc(level=5, ivs=IVS, evs=None, nature="Hardy"):
    return calculate_stats(BASE, ivs, evs or zero_evs(), level, nature)


class Reference(unittest.TestCase):
    def test_litwick_level_5(self):
        self.assertEqual(
            calc(5),
            dict(hp=20, attack=8, defense=11, special_attack=13, special_defense=11, speed=8),
        )

    def test_litwick_level_100(self):
        self.assertEqual(
            calc(100),
            dict(hp=213, attack=79, defense=125, special_attack=165, special_defense=130, speed=68),
        )


class Boundaries(unittest.TestCase):
    def test_level_1(self):
        r = calc(1)
        self.assertEqual((r["hp"], r["attack"]), (12, 5))

    def test_level_out_of_range(self):
        for bad in (0, 101, -1):
            with self.assertRaises(CalcError):
                calc(bad)
        with self.assertRaises(CalcError):
            calc(5.5)

    def test_iv_min_and_max(self):
        zero = {s: 0 for s in STATS}
        full = {s: 31 for s in STATS}
        self.assertEqual(calc(100, zero)["hp"], 210)
        self.assertEqual(calc(100, full)["hp"], 241)

    def test_iv_out_of_range(self):
        for bad in (-1, 32):
            with self.assertRaises(CalcError):
                calc(5, {**IVS, "hp": bad})

    def test_iv_incomplete_or_wrong_type(self):
        with self.assertRaises(CalcError):
            calc(5, {k: v for k, v in IVS.items() if k != "speed"})
        with self.assertRaises(CalcError):
            calc(5, {**IVS, "hp": "3"})
        with self.assertRaises(CalcError):
            calc(5, {**IVS, "hp": True})


class NatureAndEvs(unittest.TestCase):
    def test_neutral_natures_change_nothing(self):
        for n in ("Hardy", "Docile", "Serious", "Bashful", "Quirky"):
            self.assertEqual(calc(100, nature=n), calc(100))

    def test_adamant_level_100(self):
        r = calc(100, nature="Adamant")  # +Atq, -Atq.Esp
        self.assertEqual(r["attack"], 86)            # floor(79 * 1.1)
        self.assertEqual(r["special_attack"], 148)   # floor(165 * 0.9)
        self.assertEqual(r["hp"], 213)               # natureza nunca afeta HP
        self.assertEqual(r["defense"], 125)

    def test_nature_name_is_case_insensitive(self):
        self.assertEqual(canonical_nature(" adamant "), "Adamant")
        with self.assertRaises(CalcError):
            canonical_nature("Inexistente")
        self.assertIn("neutra", nature_label("Hardy"))

    def test_ev_effect(self):
        evs = {**zero_evs(), "hp": 252}
        self.assertEqual(calc(100, evs=evs)["hp"], 276)  # floor(252/4)=63

    def test_ev_limits(self):
        with self.assertRaises(CalcError):
            calc(100, evs={**zero_evs(), "hp": 253})
        with self.assertRaises(CalcError):
            calc(100, evs={**zero_evs(), "hp": -4})
        with self.assertRaises(CalcError):  # 252+252+8 = 512 > 510
            calc(100, evs={**zero_evs(), "hp": 252, "attack": 252, "speed": 8})
        ok = {**zero_evs(), "hp": 252, "attack": 252, "speed": 6}  # 510
        calc(100, evs=ok)

    def test_custom_ruleset_limit(self):
        strict = Ruleset(key="x", label="x", max_ev_total=100)
        with self.assertRaises(CalcError):
            calculate_stats(BASE, IVS, {**zero_evs(), "hp": 252}, 50, "Hardy", strict)


if __name__ == "__main__":
    unittest.main()
