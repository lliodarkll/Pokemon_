import json
import os
import random
import sqlite3
import tempfile
import unittest

from pokebot import personagem as pers
from pokebot.store import Store, StoreError


class AtributosTest(unittest.TestCase):
    def test_seis_atributos_com_abreviacao_de_3_letras(self):
        self.assertEqual([a[1] for a in pers.ATRIBUTOS],
                         ["Força", "Destreza", "Vigor", "Inteligência", "Sintonia", "Afinidade"])
        self.assertEqual([pers.ABREV[c] for c in pers.CHAVES], ["for", "des", "vig", "int", "sin", "afi"])
        self.assertTrue(all(len(a) == 3 and a.isascii() and a.islower() for a in pers.ABREV.values()))

    def test_chave_atributo_aceita_acento_maiuscula_e_abreviacao(self):
        for txt in ("Força", "forca", " FORÇA ", "for", "For"):
            self.assertEqual(pers.chave_atributo(txt), "forca")
        self.assertEqual(pers.chave_atributo("Inteligência"), "inteligencia")
        self.assertEqual(pers.chave_atributo("afi"), "afinidade")
        self.assertIsNone(pers.chave_atributo("HP"))

    def test_completar_preenche_e_descarta_lixo(self):
        out = pers.completar({"forca": 4, "vigor": "x", "destreza": True, "outro": 9})
        self.assertEqual(out["forca"], 4)
        self.assertEqual(out["vigor"], 0)
        self.assertEqual(out["destreza"], 0)
        self.assertEqual(set(out), set(pers.CHAVES))

    def test_validar_pontos(self):
        self.assertEqual(pers.validar_pontos(" 7 "), 7)
        for ruim in ("abc", "100", "-1", ""):
            with self.assertRaises(pers.PersonagemError):
                pers.validar_pontos(ruim)


class RolagemTest(unittest.TestCase):
    def test_soma_dado_pontos_e_bonus(self):
        class Fixo:
            def randint(self, a, b):
                return 13
        r = pers.rolar_atributo(4, 2, rng=Fixo())
        self.assertEqual((r["dado"], r["total"], r["crit"]), (13, 19, None))
        self.assertIn("d20 (13) + 4 + 2 = **19**", pers.texto_rolagem("Ash", "forca", r))

    def test_bonus_negativo_e_zero(self):
        class Fixo:
            def randint(self, a, b):
                return 10
        r = pers.rolar_atributo(3, -1, rng=Fixo())
        self.assertEqual(r["total"], 12)
        self.assertIn("− 1", pers.texto_rolagem("Ash", "vigor", r))
        self.assertNotIn("+ 0", pers.texto_rolagem("Ash", "vigor", pers.rolar_atributo(3, 0, rng=Fixo())))

    def test_criticos(self):
        class Dado:
            def __init__(self, v): self.v = v
            def randint(self, a, b): return self.v
        self.assertEqual(pers.rolar_atributo(0, rng=Dado(20))["crit"], "nat20")
        self.assertEqual(pers.rolar_atributo(0, rng=Dado(1))["crit"], "nat1")
        self.assertIn("20 natural", pers.texto_rolagem("A", "sintonia", pers.rolar_atributo(0, rng=Dado(20))))
        self.assertIn("1 natural", pers.texto_rolagem("A", "sintonia", pers.rolar_atributo(0, rng=Dado(1))))

    def test_dado_sempre_entre_1_e_20(self):
        rng = random.Random(1)
        dados = {pers.rolar_atributo(0, rng=rng)["dado"] for _ in range(2000)}
        self.assertEqual(dados, set(range(1, 21)))


class StorePersonagemTest(unittest.TestCase):
    def setUp(self):
        self.s = Store(":memory:")

    def test_criar_ler_atualizar_apagar(self):
        pid = self.s.create_personagem(1, 10, "  Ash   Ketchum ")
        p = self.s.get_personagem(1, pid)
        self.assertEqual(p["nome"], "Ash Ketchum")
        self.assertEqual(p["attrs"], pers.atributos_padrao())
        self.s.update_personagem(1, pid, attrs={**p["attrs"], "forca": 5}, extras={"HP": 20})
        p = self.s.get_personagem(1, pid)
        self.assertEqual((p["attrs"]["forca"], p["extras"]), (5, {"HP": 20}))
        self.s.update_personagem(1, pid, nome="Ash")
        self.assertEqual(self.s.find_personagem(1, "ASH")["id"], pid)  # sem diferenciar maiúsculas
        self.s.delete_personagem(1, pid)
        self.assertIsNone(self.s.get_personagem(1, pid))

    def test_nome_repetido_e_invalido(self):
        self.s.create_personagem(1, 10, "Ash")
        with self.assertRaises(StoreError):
            self.s.create_personagem(1, 11, "ash")
        self.s.create_personagem(2, 11, "Ash")  # outro servidor pode
        for ruim in ("", "   ", "x" * 41):
            with self.assertRaises(StoreError):
                self.s.create_personagem(1, 12, ruim)
        outro = self.s.create_personagem(1, 12, "Misty")
        with self.assertRaises(StoreError):
            self.s.update_personagem(1, outro, nome="Ash")

    def test_listar_por_dono_e_isolamento_por_servidor(self):
        self.s.create_personagem(1, 10, "B")
        self.s.create_personagem(1, 10, "A")
        self.s.create_personagem(1, 11, "C")
        self.s.create_personagem(2, 10, "D")
        self.assertEqual([p["nome"] for p in self.s.list_personagens(1, 10)], ["A", "B"])
        self.assertEqual(len(self.s.list_personagens(1)), 3)
        self.assertIsNone(self.s.find_personagem(1, "D"))

    def test_atualizar_inexistente(self):
        with self.assertRaises(StoreError):
            self.s.update_personagem(1, 999, nome="X")


class MigracaoTest(unittest.TestCase):
    def _fichas_db(self, linhas):
        d = tempfile.mkdtemp()
        path = os.path.join(d, "fichas.db")
        c = sqlite3.connect(path)
        c.execute("CREATE TABLE fichas (guild_id INTEGER, owner_id INTEGER, nome TEXT COLLATE NOCASE, "
                  "dados TEXT DEFAULT '{}', PRIMARY KEY (guild_id, nome))")
        c.executemany("INSERT INTO fichas VALUES (?,?,?,?)",
                      [(g, o, n, json.dumps(dados, ensure_ascii=False)) for g, o, n, dados in linhas])
        c.commit()
        c.close()
        return path

    def test_migra_atributos_e_preserva_campos_livres(self):
        path = self._fichas_db([
            (1, 10, "Ash", {"Força": 3, "forca ": 9, "HP": 20, "Classe": "Treinador", "Vigor": "alto"}),
            (1, 11, "Misty", {}),
            (2, 12, "Brock", {"INTELIGENCIA": 150}),  # fora do limite: vira campo livre
        ])
        s = Store(":memory:")
        self.assertEqual(s.migrate_old_fichas(path), 3)
        ash = s.find_personagem(1, "Ash")
        self.assertEqual(ash["attrs"]["forca"], 9)  # a última chave equivalente vence
        self.assertEqual(ash["extras"], {"HP": 20, "Classe": "Treinador", "Vigor": "alto"})
        self.assertEqual(ash["owner_id"], 10)
        self.assertEqual(s.find_personagem(1, "Misty")["attrs"], pers.atributos_padrao())
        brock = s.find_personagem(2, "Brock")
        self.assertEqual(brock["attrs"]["inteligencia"], 0)
        self.assertEqual(brock["extras"], {"INTELIGENCIA": 150})

    def test_migra_uma_unica_vez_e_nao_altera_o_arquivo_antigo(self):
        path = self._fichas_db([(1, 10, "Ash", {"HP": 1})])
        with open(path, "rb") as f:
            antes = f.read()
        s = Store(":memory:")
        self.assertEqual(s.migrate_old_fichas(path), 1)
        self.assertEqual(s.migrate_old_fichas(path), 0)
        self.assertEqual(len(s.list_personagens(1)), 1)
        with open(path, "rb") as f:
            self.assertEqual(f.read(), antes)

    def test_sem_arquivo_ou_sem_tabela(self):
        s = Store(":memory:")
        self.assertEqual(s.migrate_old_fichas("/caminho/que/nao/existe.db"), 0)
        d = tempfile.mkdtemp()
        vazio = os.path.join(d, "fichas.db")
        sqlite3.connect(vazio).close()
        self.assertEqual(s.migrate_old_fichas(vazio), 0)


if __name__ == "__main__":
    unittest.main()
