# Bot de fichas — RPG + módulo Pokémon

Ficha do personagem (`/ficha`) + rolagens de atributo (`/for` `/des` `/vig` `/int` `/sin` `/afi`) + `/rolar` + grupo `/pokémon` + painel `/pokédex`.

## Estrutura
- `main.py` — ponto de entrada (lê o token de `bot.env` ou da variável `DISCORD_TOKEN`)
- `bot_fichas.py` — bot base e `/rolar`
- `pokebot/personagem.py` — atributos e rolagens d20 (lógica pura)
- `pokebot/ficha_cmds.py` — `/ficha` (painel) e atalhos de rolagem
- `pokebot/calculator.py` — fórmulas oficiais de stats (sem Discord, sem rede)
- `pokebot/iv_session.py` — rolagem e atribuição de IVs (lógica pura)
- `pokebot/pokeapi.py` — PokéAPI, cache, evoluções, golpes e imagens
- `pokebot/evolution_gif.py` — GIF de evolução (Pillow)
- `pokebot/battle.py`, `store.py` (colunas de HP/golpes) — base do modo batalha (ainda sem comandos)
- `pokebot/sheet.py` / `commands.py` — ficha (embed) e comandos
- `tests/` — testes automáticos (`python -m unittest`)

## Rodar
    pip install -r requirements.txt     # no Termux: pkg install python-pillow  e  pip install discord.py
    cp bot.env.example bot.env          # e cole o token no bot.env
    python main.py

O token fica só no `bot.env` (ignorado pelo Git). Cada pessoa que testar deve usar o **próprio bot** (outro token).

## Comandos
**/pokémon** — `criar` · `cancelar` · `ver` · `listar` · `apagar` · `evoluir` · `config_dados` (mestre) · `ajuda`
**/pokédex** — painel de edição (substitui os antigos retomar, nivel, evs, natureza e atualizar)
**/ficha** — painel do personagem (substitui o antigo grupo `/ficha criar/ver/definir/...`)
**/for /des /vig /int /sin /afi** — d20 + pontos do atributo
**/rolar** — dados (`d20`, `2d6+3`)

### /ficha
- Atributos: Força, Destreza, Vigor, Inteligência, Sintonia e Afinidade (pontos fixos de 0 a 99, começam em 0).
- `/ficha` sem nome: abre a sua ficha (sem ficha, pede o nome). `/ficha Nome`: abre a de outro personagem
  (só leitura para quem não é o dono nem o mestre); nome que não existe oferece criar.
- Painel: **Atributos** (menu + `-5 -1 +1 +5` ou **Valor…**) · **Campo extra…** (livre, ex.: HP; valor vazio apaga) ·
  **Renomear…** · **Apagar** (com confirmação; os Pokémon não são apagados).
- Jogador comum tem 1 ficha (`MAX_PERSONAGENS_POR_JOGADOR` em `pokebot/personagem.py`); o mestre cria quantas quiser.
- A ficha lista os Pokémon do jogador. Equipe de 6 e PC vêm na etapa 2.
- As fichas antigas (`fichas.db`) são copiadas sozinhas na primeira vez que o bot liga: campos com nome de atributo
  viram pontos e o resto vira campo extra. O arquivo antigo não é alterado.

### /for /des /vig /int /sin /afi
Rolam **d20 + pontos** do atributo. Campos opcionais: `bonus` (modificador da cena, de −50 a 50) e `personagem`
(o mestre pode rolar por qualquer um). 20 natural e 1 natural recebem destaque.

### /pokédex
- Sem parâmetros: continua a distribuição de IVs pendente; senão abre o painel do seu Pokémon
  (com vários, pede para escolher).
- Painel: menu de **natureza** · botões de **nível** (−10 −1 +1 +10) ou **Nível…** para digitar ·
  **Espécie…** para digitar (sempre com confirmação) · **EVs** (menu do atributo, botões ou digitar).
- Atalho digitando: `/pokédex pokemon nivel especie natureza` (todos opcionais).
- Subir de nível e cruzar o requisito de evolução abre a pergunta "Evoluir?" com animação.
- IVs não mudam depois de confirmados.

### Nomes dos comandos
O Discord só aceita nomes em minúsculas (não existe "/Pokémon" com P maiúsculo). Acentos são permitidos.
No topo de `pokebot/commands.py`, `ACENTOS = True` usa `/pokémon` e `/pokédex`;
com `False` voltam `/pokemon` e `/pokedex` (reinicie o bot; o Discord pode levar alguns minutos para atualizar).

## Regras
- Fórmulas da série principal em aritmética inteira; natureza não afeta HP.
- IV 0–31; EV 0–252 por stat e 510 no total; nível 1–100.
- Permissões: só o dono edita; quem tem "Gerenciar Servidor" (mestre) edita qualquer Pokémon.

## Colaboração (Git)
- `.gitignore` já exclui `bot.env`, `*.db` e `art_cache/`.
- Uma branch por mudança, Pull Request, `python -m unittest` antes de juntar.
