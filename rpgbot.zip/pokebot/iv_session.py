"""Lógica pura da geração/atribuição de IVs (sem Discord)."""
import random
import re
from dataclasses import dataclass

from .calculator import DEFAULT_RULESET, STAT_LABELS, STATS, validate_ivs

DEFAULT_DICE = "1d32-1"


class SessionError(ValueError):
    """Erro de regra na distribuição de IVs."""


@dataclass(frozen=True)
class DiceSpec:
    count: int
    sides: int
    bonus: int = 0

    @property
    def minimum(self):
        return self.count + self.bonus

    @property
    def maximum(self):
        return self.count * self.sides + self.bonus

    @property
    def text(self):
        return f"{self.count}d{self.sides}" + (f"{self.bonus:+d}" if self.bonus else "")


_DICE_RE = re.compile(r"(\d{1,2})d(\d{1,4})([+-]\d{1,3})?")


def parse_dice(expr):
    m = _DICE_RE.fullmatch(str(expr).replace(" ", "").lower())
    if not m:
        raise SessionError("Expressão inválida. Use o formato NdL±B, por exemplo 1d32-1.")
    count, sides, bonus = int(m.group(1)), int(m.group(2)), int(m.group(3) or 0)
    if count < 1 or sides < 2:
        raise SessionError("Use ao menos 1 dado com 2 ou mais lados.")
    return DiceSpec(count, sides, bonus)


def validate_dice_for_ivs(spec, ruleset=DEFAULT_RULESET):
    """Garante que NENHUM resultado possível saia do intervalo válido de IV."""
    if spec.minimum < 0 or spec.maximum > ruleset.max_iv:
        raise SessionError(
            f"`{spec.text}` pode dar de {spec.minimum} a {spec.maximum}; "
            f"o IV precisa ficar entre 0 e {ruleset.max_iv}."
        )


def roll_ivs(expr=DEFAULT_DICE, n=6, rng=None, ruleset=DEFAULT_RULESET):
    spec = parse_dice(expr)
    validate_dice_for_ivs(spec, ruleset)
    rng = rng or random.SystemRandom()
    return [sum(rng.randint(1, spec.sides) for _ in range(spec.count)) + spec.bonus for _ in range(n)]


# ---------- atribuição: assignment = {stat: índice do dado | None} ----------
def empty_assignment():
    return {s: None for s in STATS}


def assign(assignment, stat, roll_index, n_rolls):
    """Retorna um NOVO assignment. Reatribuir um atributo libera o dado anterior."""
    if stat not in STATS:
        raise SessionError("Atributo inválido.")
    if isinstance(roll_index, bool) or not isinstance(roll_index, int) or not 0 <= roll_index < n_rolls:
        raise SessionError("Dado inválido.")
    for other, idx in assignment.items():
        if other != stat and idx == roll_index:
            raise SessionError(
                f"O dado {roll_index + 1} já está em {STAT_LABELS[other]}. Cada dado vale para um só atributo."
            )
    new = dict(assignment)
    new[stat] = roll_index
    return new


def unassigned_rolls(assignment, n_rolls):
    used = {i for i in assignment.values() if i is not None}
    return [i for i in range(n_rolls) if i not in used]


def next_open_stat(assignment):
    return next((s for s in STATS if assignment.get(s) is None), None)


def validate_complete(rolls, assignment, ruleset=DEFAULT_RULESET):
    """Valida a distribuição final e devolve {stat: IV}. Lança SessionError se faltar algo."""
    missing = [STAT_LABELS[s] for s in STATS if assignment.get(s) is None]
    if missing:
        raise SessionError(f"Faltam atributos: {', '.join(missing)}.")
    idxs = [assignment[s] for s in STATS]
    if any(isinstance(i, bool) or not isinstance(i, int) or not 0 <= i < len(rolls) for i in idxs):
        raise SessionError("Há dado inválido na distribuição.")
    if len(set(idxs)) != len(idxs):
        raise SessionError("Há dado repetido na distribuição.")
    if len(idxs) != len(rolls):
        raise SessionError("Todos os dados rolados precisam ser usados.")
    ivs = {s: rolls[assignment[s]] for s in STATS}
    validate_ivs(ivs, ruleset)
    return ivs
