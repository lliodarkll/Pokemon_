"""Motor de cálculo de stats Pokémon (fórmulas oficiais da série principal).

Módulo independente: não importa Discord, banco de dados nem rede.
Toda a matemática é feita com inteiros (sem float), na ordem oficial de
arredondamento: floor(...) só onde a fórmula manda.
"""
from dataclasses import dataclass

STATS = ("hp", "attack", "defense", "special_attack", "special_defense", "speed")

STAT_LABELS = {
    "hp": "HP",
    "attack": "Ataque",
    "defense": "Defesa",
    "special_attack": "Ataque Especial",
    "special_defense": "Defesa Especial",
    "speed": "Velocidade",
}
STAT_SHORT = {
    "hp": "HP",
    "attack": "Atq",
    "defense": "Def",
    "special_attack": "Atq.Esp",
    "special_defense": "Def.Esp",
    "speed": "Vel",
}


class CalcError(ValueError):
    """Entrada inválida para o cálculo."""


@dataclass(frozen=True)
class Ruleset:
    key: str = "gen3+"
    label: str = "Gen 3+ (padrão)"
    max_iv: int = 31
    max_ev_per_stat: int = 252
    max_ev_total: int = 510
    min_level: int = 1
    max_level: int = 100


DEFAULT_RULESET = Ruleset()
RULESETS = {DEFAULT_RULESET.key: DEFAULT_RULESET}

# nome -> (stat que sobe, stat que desce) | None para natureza neutra
NATURES = {
    "Hardy": None, "Docile": None, "Serious": None, "Bashful": None, "Quirky": None,
    "Lonely": ("attack", "defense"), "Brave": ("attack", "speed"),
    "Adamant": ("attack", "special_attack"), "Naughty": ("attack", "special_defense"),
    "Bold": ("defense", "attack"), "Relaxed": ("defense", "speed"),
    "Impish": ("defense", "special_attack"), "Lax": ("defense", "special_defense"),
    "Timid": ("speed", "attack"), "Hasty": ("speed", "defense"),
    "Jolly": ("speed", "special_attack"), "Naive": ("speed", "special_defense"),
    "Modest": ("special_attack", "attack"), "Mild": ("special_attack", "defense"),
    "Quiet": ("special_attack", "speed"), "Rash": ("special_attack", "special_defense"),
    "Calm": ("special_defense", "attack"), "Gentle": ("special_defense", "defense"),
    "Sassy": ("special_defense", "speed"), "Careful": ("special_defense", "special_attack"),
}
DEFAULT_NATURE = "Hardy"


# ---------- validação ----------
def _check_int(value, name):
    if isinstance(value, bool) or not isinstance(value, int):
        raise CalcError(f"{name} deve ser um número inteiro.")


def _check_keys(data, what):
    if not isinstance(data, dict):
        raise CalcError(f"{what} inválidos.")
    missing = [STAT_LABELS[s] for s in STATS if s not in data]
    if missing:
        raise CalcError(f"{what} incompletos. Faltam: {', '.join(missing)}.")
    extra = [k for k in data if k not in STATS]
    if extra:
        raise CalcError(f"{what} com atributo desconhecido: {', '.join(map(str, extra))}.")


def validate_level(level, ruleset=DEFAULT_RULESET):
    _check_int(level, "O nível")
    if not ruleset.min_level <= level <= ruleset.max_level:
        raise CalcError(f"O nível deve estar entre {ruleset.min_level} e {ruleset.max_level}.")


def validate_ivs(ivs, ruleset=DEFAULT_RULESET):
    _check_keys(ivs, "IVs")
    for s in STATS:
        _check_int(ivs[s], f"O IV de {STAT_LABELS[s]}")
        if not 0 <= ivs[s] <= ruleset.max_iv:
            raise CalcError(f"O IV de {STAT_LABELS[s]} deve estar entre 0 e {ruleset.max_iv}.")


def validate_evs(evs, ruleset=DEFAULT_RULESET):
    _check_keys(evs, "EVs")
    for s in STATS:
        _check_int(evs[s], f"O EV de {STAT_LABELS[s]}")
        if not 0 <= evs[s] <= ruleset.max_ev_per_stat:
            raise CalcError(
                f"O EV de {STAT_LABELS[s]} deve estar entre 0 e {ruleset.max_ev_per_stat}."
            )
    total = sum(evs[s] for s in STATS)
    if total > ruleset.max_ev_total:
        raise CalcError(f"Total de EVs ({total}) passa do limite de {ruleset.max_ev_total}.")


def validate_base(base):
    _check_keys(base, "Stats base")
    for s in STATS:
        _check_int(base[s], f"O stat base de {STAT_LABELS[s]}")
        if base[s] < 1:
            raise CalcError(f"O stat base de {STAT_LABELS[s]} deve ser positivo.")


def canonical_nature(name):
    wanted = str(name).strip().lower()
    for key in NATURES:
        if key.lower() == wanted:
            return key
    raise CalcError(f"Natureza desconhecida: {name}.")


def zero_evs():
    return {s: 0 for s in STATS}


def nature_percent(nature, stat):
    """Modificador da natureza em % inteiro: 110, 90 ou 100."""
    effect = NATURES[canonical_nature(nature)]
    if effect is None:
        return 100
    up, down = effect
    if stat == up:
        return 110
    if stat == down:
        return 90
    return 100


def nature_label(nature):
    key = canonical_nature(nature)
    effect = NATURES[key]
    if effect is None:
        return f"{key} (neutra)"
    return f"{key} (+{STAT_SHORT[effect[0]]}, −{STAT_SHORT[effect[1]]})"


# ---------- fórmulas ----------
def calc_hp(base, iv, ev, level):
    return ((2 * base + iv + ev // 4) * level) // 100 + level + 10


def calc_other(base, iv, ev, level, percent=100):
    intermediate = ((2 * base + iv + ev // 4) * level) // 100 + 5
    return intermediate * percent // 100  # floor(Intermediate * modificador)


def calculate_stats(base, ivs, evs, level, nature=DEFAULT_NATURE, ruleset=DEFAULT_RULESET):
    """Retorna {stat: valor final}. Valida tudo antes de calcular."""
    validate_base(base)
    validate_level(level, ruleset)
    validate_ivs(ivs, ruleset)
    validate_evs(evs, ruleset)
    nature = canonical_nature(nature)
    result = {"hp": calc_hp(base["hp"], ivs["hp"], evs["hp"], level)}
    for s in STATS[1:]:
        result[s] = calc_other(base[s], ivs[s], evs[s], level, nature_percent(nature, s))
    return result
