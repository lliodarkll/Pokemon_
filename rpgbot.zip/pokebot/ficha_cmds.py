"""Camada Discord: /ficha (painel do personagem) e atalhos de rolagem /for /des /vig /int /sin /afi."""
import logging
from typing import Optional

import discord
from discord import app_commands

from . import personagem as pers
from .commands import ConfirmView, NumberModal, TextModal, can_edit, is_admin
from .store import StoreError

log = logging.getLogger("pokebot")

MAX_NA_FICHA = 6  # quantos Pokémon aparecem listados na ficha (a equipe completa vem na etapa 2)


def build_embed(p, pokes):
    e = discord.Embed(title=f"📝 {p['nome']}", description=f"Jogador: <@{p['owner_id']}>", color=0x5865F2)
    linhas = [f"{pers.EMOJIS[c]} **{pers.NOMES[c]}** · {p['attrs'][c]}" for c in pers.CHAVES]
    e.add_field(name="Atributos", value="\n".join(linhas), inline=False)
    if not pokes:
        poke_txt = "Nenhum Pokémon ainda."
    else:
        poke_txt = "\n".join(
            f"• {x['species']['display_name']} Nv.{x['level']}" for x in pokes[:MAX_NA_FICHA]
        )
        if len(pokes) > MAX_NA_FICHA:
            poke_txt += f"\n… e mais {len(pokes) - MAX_NA_FICHA}"
    e.add_field(name=f"🎒 Pokémon ({len(pokes)})", value=poke_txt, inline=False)
    for campo, valor in list(p["extras"].items())[:10]:
        e.add_field(name=str(campo)[:256], value=str(valor)[:1024] or "—", inline=True)
    e.set_footer(text="Rolar d20 + atributo: " + " ".join(f"/{pers.ABREV[c]}" for c in pers.CHAVES))
    return e


def converter(valor):
    try:
        return int(valor)
    except ValueError:
        return valor


class ExtraModal(discord.ui.Modal):
    """Campo livre (como nas fichas antigas): nome + valor. Valor vazio apaga o campo."""

    def __init__(self, on_submit_cb):
        super().__init__(title="Campo extra")
        self.cb = on_submit_cb
        self.campo = discord.ui.TextInput(label="Nome do campo", placeholder="ex.: HP", max_length=40)
        self.valor = discord.ui.TextInput(
            label="Valor (vazio apaga o campo)", required=False, max_length=100
        )
        self.add_item(self.campo)
        self.add_item(self.valor)

    async def on_submit(self, interaction):
        await self.cb(interaction, self.campo.value.strip(), self.valor.value.strip())


class CreateModal(discord.ui.Modal):
    def __init__(self, on_name):
        super().__init__(title="Criar personagem")
        self.on_name = on_name
        self.nome = discord.ui.TextInput(label="Nome do personagem", max_length=40)
        self.add_item(self.nome)

    async def on_submit(self, interaction):
        await self.on_name(interaction, self.nome.value.strip())


class FichaView(discord.ui.View):
    """Painel da ficha: botões de ação e submenu de atributos (menu + botões ou digitar)."""

    def __init__(self, store, p, mode="main", attr="forca"):
        super().__init__(timeout=900)
        self.store = store
        self.pid, self.guild_id, self.owner_id = p["id"], p["guild_id"], p["owner_id"]
        self.mode, self.attr = mode, attr
        if mode == "attrs":
            self._build_attrs(p)
        else:
            self._build_main()

    def _btn(self, label, style, row, cb, disabled=False, emoji=None):
        b = discord.ui.Button(label=label, style=style, row=row, disabled=disabled, emoji=emoji)
        b.callback = cb
        self.add_item(b)

    def _build_main(self):
        self._btn("Atributos", discord.ButtonStyle.primary, 0, self.on_open_attrs, emoji="📊")
        self._btn("Campo extra…", discord.ButtonStyle.secondary, 0, self.on_extra, emoji="➕")
        self._btn("Renomear…", discord.ButtonStyle.secondary, 0, self.on_rename, emoji="✏️")
        self._btn("Apagar", discord.ButtonStyle.danger, 1, self.on_delete, emoji="🗑️")
        self._btn("Fechar", discord.ButtonStyle.secondary, 1, self.on_close, emoji="✖️")

    def _build_attrs(self, p):
        sel = discord.ui.Select(
            placeholder="Atributo", row=0,
            options=[
                discord.SelectOption(
                    label=f"{pers.NOMES[c]}: {p['attrs'][c]}", value=c, emoji=pers.EMOJIS[c],
                    default=(c == self.attr),
                )
                for c in pers.CHAVES
            ],
        )
        sel.callback = self.on_attr
        self.add_item(sel)
        atual = p["attrs"][self.attr]
        for d in (-5, -1, 1, 5):
            bloqueado = (d < 0 and atual <= pers.PONTOS_MIN) or (d > 0 and atual >= pers.PONTOS_MAX)
            self._btn(f"{d:+d}", discord.ButtonStyle.danger if d < 0 else discord.ButtonStyle.success,
                      1, self._delta_cb(d), disabled=bloqueado)
        self._btn("Valor…", discord.ButtonStyle.secondary, 1, self.on_value_modal, emoji="🔢")
        self._btn("Voltar", discord.ButtonStyle.secondary, 2, self.on_back, emoji="↩️")

    # -- util --
    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id or interaction.user.guild_permissions.manage_guild:
            return True
        await interaction.response.send_message(
            "Só o dono da ficha ou o mestre mexe neste painel.", ephemeral=True
        )
        return False

    def _load(self):
        return self.store.get_personagem(self.guild_id, self.pid)

    def _pokes(self, p):
        return self.store.list_pokemon(self.guild_id, p["owner_id"])

    async def _gone(self, interaction):
        self.stop()
        await interaction.response.edit_message(content="Essa ficha não existe mais.", embed=None, view=None)

    async def _redraw(self, interaction, p, mode=None, attr=None):
        self.stop()
        await interaction.response.edit_message(
            content=None, embed=build_embed(p, self._pokes(p)),
            view=FichaView(self.store, p, mode or self.mode, attr or self.attr),
        )

    # -- atributos --
    async def on_open_attrs(self, interaction):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        await self._redraw(interaction, p, mode="attrs")

    async def on_back(self, interaction):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        await self._redraw(interaction, p, mode="main")

    async def on_attr(self, interaction):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        chave = interaction.data["values"][0]
        if chave not in pers.CHAVES:
            return await interaction.response.send_message("Atributo inválido.", ephemeral=True)
        await self._redraw(interaction, p, mode="attrs", attr=chave)

    async def set_points(self, interaction, p, valor):
        valor = max(pers.PONTOS_MIN, min(pers.PONTOS_MAX, valor))
        self.store.update_personagem(self.guild_id, self.pid, attrs={**p["attrs"], self.attr: valor})
        await self._redraw(interaction, self._load(), mode="attrs")

    def _delta_cb(self, delta):
        async def cb(interaction):
            p = self._load()
            if not p:
                return await self._gone(interaction)
            await self.set_points(interaction, p, p["attrs"][self.attr] + delta)
        return cb

    async def apply_value(self, interaction, n):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        await self.set_points(interaction, p, n)

    async def on_value_modal(self, interaction):
        label = f"Pontos de {pers.NOMES[self.attr]} ({pers.PONTOS_MIN}–{pers.PONTOS_MAX})"
        await interaction.response.send_modal(
            NumberModal("Atributo", label, pers.PONTOS_MIN, pers.PONTOS_MAX, self.apply_value)
        )

    # -- campo extra / renomear --
    async def apply_extra(self, interaction, campo, valor):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        if not campo:
            return await interaction.response.send_message("❌ Digite o nome do campo.", ephemeral=True)
        if pers.chave_atributo(campo):
            return await interaction.response.send_message(
                f"❌ **{campo}** é um atributo: use o botão **Atributos**.", ephemeral=True
            )
        extras = dict(p["extras"])
        if valor:
            extras[campo] = converter(valor)
        elif extras.pop(campo, None) is None:
            return await interaction.response.send_message("❌ Esse campo não existe.", ephemeral=True)
        self.store.update_personagem(self.guild_id, self.pid, extras=extras)
        await self._redraw(interaction, self._load())

    async def on_extra(self, interaction):
        await interaction.response.send_modal(ExtraModal(self.apply_extra))

    async def apply_rename(self, interaction, nome):
        p = self._load()
        if not p:
            return await self._gone(interaction)
        try:
            self.store.update_personagem(self.guild_id, self.pid, nome=nome)
        except StoreError as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        await self._redraw(interaction, self._load())

    async def on_rename(self, interaction):
        await interaction.response.send_modal(
            TextModal("Renomear personagem", "Novo nome", "máx. 40 caracteres", self.apply_rename)
        )

    # -- apagar / fechar --
    async def on_delete(self, interaction):
        p = self._load()
        if not p:
            return await self._gone(interaction)

        async def do(i):
            self.store.delete_personagem(self.guild_id, self.pid)
            await i.response.edit_message(
                content=f"Ficha **{p['nome']}** apagada. 🗑️", embed=None, view=None
            )

        await interaction.response.send_message(
            f"Apagar a ficha **{p['nome']}**? Os Pokémon dela não são apagados.",
            view=ConfirmView(interaction.user.id, do), ephemeral=True,
        )

    async def on_close(self, interaction):
        p = self._load()
        self.stop()
        if not p:
            return await interaction.response.edit_message(content="Essa ficha não existe mais.", embed=None, view=None)
        await interaction.response.edit_message(content=None, embed=build_embed(p, self._pokes(p)), view=None)


class PickView(discord.ui.View):
    """Quando há vários personagens e nenhum foi indicado: menu para escolher."""

    def __init__(self, store, owner_id, lista):
        super().__init__(timeout=300)
        self.store, self.owner_id = store, owner_id
        sel = discord.ui.Select(
            placeholder="Escolha o personagem",
            options=[discord.SelectOption(label=p["nome"][:100], value=str(p["id"])) for p in lista[:25]],
        )
        sel.callback = self.on_pick
        self.add_item(sel)

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Esse menu é de quem abriu.", ephemeral=True)
            return False
        return True

    async def on_pick(self, interaction):
        p = self.store.get_personagem(interaction.guild_id, int(interaction.data["values"][0]))
        self.stop()
        if not p:
            return await interaction.response.edit_message(content="Essa ficha não existe mais.", view=None)
        await interaction.response.edit_message(
            content=None, embed=build_embed(p, self.store.list_pokemon(p["guild_id"], p["owner_id"])),
            view=FichaView(self.store, p),
        )


def register(tree, store):
    async def pers_ac(inter, current, so_meus):
        rows = store.list_personagens(inter.guild_id, inter.user.id if so_meus and not is_admin(inter) else None)
        q = current.lower()
        return [app_commands.Choice(name=p["nome"][:100], value=p["nome"]) for p in rows if q in p["nome"].lower()][:25]

    async def ver_ac(inter, current):
        return await pers_ac(inter, current, False)

    async def meus_ac(inter, current):
        return await pers_ac(inter, current, True)

    def pode_criar(inter):
        if is_admin(inter):
            return True
        return len(store.list_personagens(inter.guild_id, inter.user.id)) < pers.MAX_PERSONAGENS_POR_JOGADOR

    async def mostrar(inter, p):
        kwargs = {"embed": build_embed(p, store.list_pokemon(inter.guild_id, p["owner_id"]))}
        if can_edit(inter, p["owner_id"]):
            kwargs["view"] = FichaView(store, p)
        await inter.response.send_message(**kwargs)

    async def criar_e_mostrar(inter, nome):
        """Cria o personagem do usuário e abre o painel (responde à interação recebida)."""
        if not pode_criar(inter):
            return await inter.response.send_message("Você já tem uma ficha de personagem.", ephemeral=True)
        try:
            pid = store.create_personagem(inter.guild_id, inter.user.id, nome)
        except StoreError as e:
            return await inter.response.send_message(f"❌ {e}", ephemeral=True)
        p = store.get_personagem(inter.guild_id, pid)
        await inter.response.send_message(
            embed=build_embed(p, store.list_pokemon(inter.guild_id, p["owner_id"])), view=FichaView(store, p)
        )

    @app_commands.command(name="ficha", description="Ficha do personagem: atributos e Pokémon")
    @app_commands.describe(nome="Nome do personagem (vazio = o seu; nome novo cria a ficha)")
    @app_commands.autocomplete(nome=ver_ac)
    @app_commands.guild_only()
    async def ficha(inter: discord.Interaction, nome: Optional[str] = None):
        if nome:
            p = store.find_personagem(inter.guild_id, nome)
            if p:
                return await mostrar(inter, p)
            if not pode_criar(inter):
                return await inter.response.send_message(
                    f"Não existe o personagem **{nome}**, e você já tem a sua ficha (use `/ficha` sem nome).",
                    ephemeral=True,
                )

            async def do(i):
                await criar_e_mostrar_edit(i, nome)

            return await inter.response.send_message(
                f"Não existe o personagem **{nome}**. Criar essa ficha para você?",
                view=ConfirmView(inter.user.id, do), ephemeral=True,
            )
        own = store.list_personagens(inter.guild_id, inter.user.id)
        if not own:
            return await inter.response.send_modal(CreateModal(criar_e_mostrar))
        if len(own) == 1:
            return await mostrar(inter, own[0])
        await inter.response.send_message("Escolha o personagem:", view=PickView(store, inter.user.id, own))

    async def criar_e_mostrar_edit(i, nome):
        """Versão do 'criar' para quando a resposta é a edição da mensagem de confirmação."""
        pid = store.create_personagem(i.guild_id, i.user.id, nome)  # StoreError é tratado pelo ConfirmView
        p = store.get_personagem(i.guild_id, pid)
        await i.response.edit_message(
            content=None, embed=build_embed(p, store.list_pokemon(i.guild_id, p["owner_id"])),
            view=FichaView(store, p),
        )

    async def resolver(inter, nome):
        if nome:
            p = store.find_personagem(inter.guild_id, nome)
            if not p:
                await inter.response.send_message("Personagem não encontrado. Escolha um da lista.", ephemeral=True)
                return None
            if not can_edit(inter, p["owner_id"]):
                await inter.response.send_message("Só o dono ou o mestre rola por este personagem.", ephemeral=True)
                return None
            return p
        own = store.list_personagens(inter.guild_id, inter.user.id)
        if len(own) == 1:
            return own[0]
        msg = ("Você ainda não tem ficha. Use `/ficha` para criar a sua." if not own
               else "Você tem mais de um personagem: escolha no campo **personagem**.")
        await inter.response.send_message(msg, ephemeral=True)
        return None

    def fazer_rolagem(chave):
        nome_attr, abrev = pers.NOMES[chave], pers.ABREV[chave]

        @app_commands.command(name=abrev, description=f"Rola d20 + {nome_attr}")
        @app_commands.describe(
            bonus="Bônus ou penalidade da cena (ex.: 2 ou -1)",
            personagem="Qual personagem (vazio = o seu)",
        )
        @app_commands.autocomplete(personagem=meus_ac)
        @app_commands.guild_only()
        async def rolagem(
            inter: discord.Interaction,
            bonus: app_commands.Range[int, -50, 50] = 0,
            personagem: Optional[str] = None,
        ):
            p = await resolver(inter, personagem)
            if not p:
                return
            r = pers.rolar_atributo(p["attrs"][chave], bonus)
            await inter.response.send_message(pers.texto_rolagem(p["nome"], chave, r))

        return rolagem

    tree.add_command(ficha)
    for chave in pers.CHAVES:
        tree.add_command(fazer_rolagem(chave))
