"""Acesso à PokéAPI com cache (memória + SQLite) e tratamento de erros."""
import asyncio
import hashlib
import logging
import os
import re
from dataclasses import dataclass

from .calculator import STATS

log = logging.getLogger("pokebot.api")

API = "https://pokeapi.co/api/v2"
STAT_MAP = {
    "hp": "hp", "attack": "attack", "defense": "defense",
    "special-attack": "special_attack", "special-defense": "special_defense", "speed": "speed",
}


class PokeApiError(Exception):
    pass


class SpeciesNotFound(PokeApiError):
    pass


class ApiUnavailable(PokeApiError):
    pass


class MoveNotFound(PokeApiError):
    pass


@dataclass
class Species:
    identifier: str
    display_name: str
    dex: int | None
    types: list
    base: dict
    artwork: str | None = None
    species_name: str | None = None  # nome da espécie (sem forma), usado na cadeia de evolução

    def to_dict(self):
        return {
            "identifier": self.identifier, "display_name": self.display_name, "dex": self.dex,
            "types": self.types, "base": self.base, "artwork": self.artwork,
            "species_name": self.species_name,
        }

    @classmethod
    def from_dict(cls, d):
        return cls(d["identifier"], d["display_name"], d.get("dex"), d["types"], d["base"],
                   d.get("artwork"), d.get("species_name"))


@dataclass
class Evolution:
    target: str            # nome da espécie de destino (ex.: "lampent")
    min_level: int | None
    plain_level: bool      # True = evolui só por nível, sem outra condição
    requirement: str       # texto legível: "Nv. 41", "Dusk Stone", "Troca"...

    def to_dict(self):
        return {"target": self.target, "min_level": self.min_level,
                "plain_level": self.plain_level, "requirement": self.requirement}

    @classmethod
    def from_dict(cls, d):
        return cls(d["target"], d.get("min_level"), d["plain_level"], d["requirement"])


@dataclass
class Move:
    identifier: str
    display_name: str
    type: str
    category: str          # physical | special | status
    power: int | None
    accuracy: int | None   # None = não erra
    pp: int

    def to_dict(self):
        return {"identifier": self.identifier, "display_name": self.display_name, "type": self.type,
                "category": self.category, "power": self.power, "accuracy": self.accuracy, "pp": self.pp}

    @classmethod
    def from_dict(cls, d):
        return cls(d["identifier"], d["display_name"], d["type"], d["category"],
                   d.get("power"), d.get("accuracy"), d["pp"])


def parse_move(data):
    try:
        en = next((n["name"] for n in data.get("names", []) if n["language"]["name"] == "en"), None)
        return Move(
            data["name"], en or _pretty(data["name"]), data["type"]["name"], data["damage_class"]["name"],
            data.get("power"), data.get("accuracy"), int(data.get("pp") or 1),
        )
    except (KeyError, TypeError, ValueError, StopIteration) as e:
        raise PokeApiError("Resposta da PokéAPI sobre o golpe em formato inesperado.") from e


def parse_learnset(data):
    """{golpe: menor nível em que é aprendido por level-up | None (só TM/ovo/tutor)}."""
    try:
        result = {}
        for m in data.get("moves", []):
            level = None
            for vg in m["version_group_details"]:
                if vg["move_learn_method"]["name"] == "level-up":
                    lv = max(1, int(vg["level_learned_at"]))
                    level = lv if level is None else min(level, lv)
            result[m["move"]["name"]] = level
        return result
    except (KeyError, TypeError, ValueError) as e:
        raise PokeApiError("Lista de golpes em formato inesperado.") from e


def normalize_name(raw):
    s = str(raw).strip().lower().replace("♀", "-f").replace("♂", "-m")
    s = re.sub(r"[.'’:]", "", s)
    s = re.sub(r"[\s_]+", "-", s)
    return s.strip("-")


def parse_pokemon(data):
    """Converte a resposta de /pokemon/{x} em Species. Função pura (testável)."""
    try:
        base = {}
        for entry in data["stats"]:
            key = STAT_MAP.get(entry["stat"]["name"])
            if key:
                base[key] = int(entry["base_stat"])
        if any(s not in base for s in STATS):
            raise PokeApiError("A PokéAPI devolveu stats base incompletos.")
        types = [t["type"]["name"] for t in sorted(data["types"], key=lambda t: t["slot"])]
        m = re.search(r"/pokemon-species/(\d+)/?$", (data.get("species") or {}).get("url", ""))
        dex = int(m.group(1)) if m else (data["id"] if data["id"] < 10000 else None)
        sprites = data.get("sprites") or {}
        art = (((sprites.get("other") or {}).get("official-artwork") or {}).get("front_default")
               or sprites.get("front_default"))
        name = data["name"]
        species_name = (data.get("species") or {}).get("name") or name
        return Species(name, name.replace("-", " ").title(), dex, types, base, art, species_name)
    except PokeApiError:
        raise
    except (KeyError, TypeError, ValueError) as e:
        raise PokeApiError("Resposta da PokéAPI em formato inesperado.") from e


_COND_FIELDS = (
    "gender", "held_item", "item", "known_move", "known_move_type", "location", "min_affection",
    "min_beauty", "min_happiness", "needs_overworld_rain", "party_species", "party_type",
    "relative_physical_stats", "time_of_day", "trade_species", "turn_upside_down",
)


def _pretty(name):
    return str(name).replace("-", " ").title()


def _is_plain_level(detail):
    if (detail.get("trigger") or {}).get("name") != "level-up" or not detail.get("min_level"):
        return False
    return not any(detail.get(f) for f in _COND_FIELDS)


def describe_requirement(detail):
    parts = []
    trig = (detail.get("trigger") or {}).get("name", "")
    if detail.get("min_level"):
        parts.append(f"Nv. {detail['min_level']}")
    if detail.get("item"):
        parts.append(_pretty(detail["item"]["name"]))
    if trig == "trade":
        parts.append("Troca")
    if detail.get("held_item"):
        parts.append("segurando " + _pretty(detail["held_item"]["name"]))
    if detail.get("min_happiness") or detail.get("min_affection"):
        parts.append("amizade")
    if detail.get("time_of_day"):
        parts.append({"day": "de dia", "night": "de noite"}.get(detail["time_of_day"], detail["time_of_day"]))
    if detail.get("known_move"):
        parts.append("sabendo " + _pretty(detail["known_move"]["name"]))
    if detail.get("location"):
        parts.append("em local especial")
    if detail.get("gender"):
        parts.append("fêmea" if detail["gender"] == 1 else "macho")
    return " + ".join(parts) if parts else _pretty(trig or "condição especial")


def _find_node(node, species_name):
    if node["species"]["name"] == species_name:
        return node
    for child in node.get("evolves_to", []):
        found = _find_node(child, species_name)
        if found:
            return found
    return None


def parse_evolutions(chain, species_name):
    """chain = JSON['chain'] de /evolution-chain/{id}. Retorna as evoluções DIRETAS da espécie."""
    try:
        node = _find_node(chain, species_name)
        if node is None:
            return []
        result = []
        for child in node.get("evolves_to", []):
            details = child.get("evolution_details") or [{}]
            chosen = next((d for d in details if _is_plain_level(d)), details[0])
            plain = _is_plain_level(chosen)
            result.append(Evolution(
                child["species"]["name"], chosen.get("min_level"), plain, describe_requirement(chosen),
            ))
        return result
    except (KeyError, TypeError, AttributeError) as e:
        raise PokeApiError("Cadeia de evolução em formato inesperado.") from e


def available_evolutions(evos, level, admin=False):
    """Nível atingido libera as evoluções puras por nível; item/troca/condição só com o mestre."""
    return [e for e in evos if (e.plain_level and level >= e.min_level) or (not e.plain_level and admin)]


def newly_ready(evos, old_level, new_level):
    """Evoluções por nível cujo requisito foi cruzado agora."""
    return [e for e in evos if e.plain_level and old_level < e.min_level <= new_level]


async def http_fetch_bytes(url):
    import aiohttp

    try:
        timeout = aiohttp.ClientTimeout(total=15)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status != 200:
                    raise ApiUnavailable(f"Falha ao baixar imagem (status {resp.status}).")
                data = await resp.read()
                if len(data) > 8_000_000:
                    raise ApiUnavailable("Imagem grande demais.")
                return data
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        raise ApiUnavailable("Não consegui baixar a imagem (rede/timeout).") from e


async def http_fetch_json(url):
    import aiohttp  # import tardio: os testes não precisam da biblioteca

    try:
        timeout = aiohttp.ClientTimeout(total=10)
        async with aiohttp.ClientSession(timeout=timeout) as session:
            async with session.get(url) as resp:
                if resp.status == 404:
                    raise SpeciesNotFound(url)
                if resp.status != 200:
                    raise ApiUnavailable(f"A PokéAPI respondeu com status {resp.status}.")
                return await resp.json()
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        raise ApiUnavailable("Não consegui falar com a PokéAPI (rede/timeout).") from e


class PokeApiClient:
    def __init__(self, store=None, fetch_json=None, retries=2, retry_delay=0.7,
                 fetch_bytes=None, image_dir="art_cache"):
        self.store = store
        self._fetch = fetch_json or http_fetch_json
        self._fetch_bytes = fetch_bytes or http_fetch_bytes
        self.image_dir = image_dir
        self.retries = retries
        self.retry_delay = retry_delay
        self._mem = {}
        self._names = None

    async def _get(self, url):
        last = None
        for attempt in range(self.retries):
            try:
                return await self._fetch(url)
            except ApiUnavailable as e:
                last = e
                log.warning("PokéAPI indisponível (%s), tentativa %d", url, attempt + 1)
                if attempt + 1 < self.retries:
                    await asyncio.sleep(self.retry_delay)
        raise last

    async def get_species(self, name):
        ident = normalize_name(name)
        if not ident:
            raise SpeciesNotFound(str(name))
        if ident in self._mem:
            return self._mem[ident]
        if self.store:
            cached = self.store.cache_get(f"species:{ident}")
            if cached:
                sp = Species.from_dict(cached)
                self._mem[ident] = sp
                return sp
        try:
            try:
                data = await self._get(f"{API}/pokemon/{ident}")
            except SpeciesNotFound:
                # nomes de espécie sem forma padrão (ex.: wormadam, meowstic): usa a variedade padrão
                data = await self._default_variety(ident)
        except SpeciesNotFound:
            raise SpeciesNotFound(str(name)) from None
        sp = parse_pokemon(data)
        for key in {ident, sp.identifier}:
            self._mem[key] = sp
            if self.store:
                self.store.cache_put(f"species:{key}", sp.to_dict())
        return sp

    async def list_names(self):
        if self._names:
            return self._names
        if self.store:
            cached = self.store.cache_get("names", max_age_days=7)
            if cached:
                self._names = cached
                return cached
        data = await self._get(f"{API}/pokemon?limit=3000")
        try:
            names = [r["name"] for r in data["results"]]
        except (KeyError, TypeError) as e:
            raise PokeApiError("Lista de espécies em formato inesperado.") from e
        self._names = names
        if self.store:
            self.store.cache_put("names", names)
        return names

    async def _default_variety(self, ident):
        sdata = await self._get(f"{API}/pokemon-species/{ident}")  # 404 -> SpeciesNotFound
        try:
            variety = next(v for v in sdata["varieties"] if v["is_default"])["pokemon"]["name"]
        except (KeyError, TypeError, StopIteration) as e:
            raise PokeApiError("Espécie sem variedade padrão.") from e
        return await self._get(f"{API}/pokemon/{variety}")

    async def get_evolutions(self, species):
        """Evoluções diretas de um Species. Lista vazia = forma final / sem evolução."""
        name = species.species_name or species.identifier
        key = f"evo:{name}"
        if self.store:
            cached = self.store.cache_get(key)
            if cached is not None:
                return [Evolution.from_dict(d) for d in cached]
        try:
            sdata = await self._get(f"{API}/pokemon-species/{name}")
        except SpeciesNotFound:
            raise PokeApiError("Espécie não encontrada na PokéAPI.") from None
        try:
            chain_url = (sdata.get("evolution_chain") or {}).get("url")
        except AttributeError as e:
            raise PokeApiError("Resposta inesperada da PokéAPI.") from e
        evos = []
        if chain_url:
            chain = await self._get(chain_url)
            try:
                evos = parse_evolutions(chain["chain"], name)
            except KeyError as e:
                raise PokeApiError("Cadeia de evolução em formato inesperado.") from e
        if self.store:
            self.store.cache_put(key, [e.to_dict() for e in evos])
        return evos

    async def get_image(self, url):
        """Baixa uma imagem com cache em disco (art_cache/)."""
        os.makedirs(self.image_dir, exist_ok=True)
        path = os.path.join(self.image_dir, hashlib.sha1(url.encode()).hexdigest() + ".img")
        if os.path.exists(path):
            with open(path, "rb") as f:
                return f.read()
        data = await self._fetch_bytes(url)
        with open(path, "wb") as f:
            f.write(data)
        return data

    async def get_move(self, name):
        ident = normalize_name(name)
        if not ident:
            raise MoveNotFound(str(name))
        if self.store:
            cached = self.store.cache_get(f"move:{ident}")
            if cached:
                return Move.from_dict(cached)
        try:
            data = await self._get(f"{API}/move/{ident}")
        except SpeciesNotFound:
            raise MoveNotFound(str(name)) from None
        mv = parse_move(data)
        if self.store:
            self.store.cache_put(f"move:{ident}", mv.to_dict())
        return mv

    async def get_learnset(self, identifier):
        key = f"learnset:{identifier}"
        if self.store:
            cached = self.store.cache_get(key)
            if cached is not None:
                return cached
        learn = parse_learnset(await self._get(f"{API}/pokemon/{identifier}"))
        if self.store:
            self.store.cache_put(key, learn)
        return learn
