"""Apresentação: monta os embeds da ficha e da sessão de IVs."""
import discord

from .calculator import (
    DEFAULT_RULESET, RULESETS, STAT_LABELS, STAT_SHORT, STATS, calculate_stats, nature_label,
)

# O Discord não colore campos individualmente; quadrados coloridos fazem esse papel.
# (não existe quadrado "azul-petróleo": verde representa o teal; ⬜ representa o cinza)
STAT_EMOJI = {
    "hp": "🟥", "attack": "🟧", "defense": "🟦",
    "special_attack": "🟪", "special_defense": "🟩", "speed": "⬜",
}

TYPE_PT = {
    "normal": "Normal", "fire": "Fogo", "water": "Água", "grass": "Planta", "electric": "Elétrico",
    "ice": "Gelo", "fighting": "Lutador", "poison": "Veneno", "ground": "Terra", "flying": "Voador",
    "psychic": "Psíquico", "bug": "Inseto", "rock": "Pedra", "ghost": "Fantasma", "dragon": "Dragão",
    "dark": "Sombrio", "steel": "Aço", "fairy": "Fada",
}
TYPE_COLOR = {
    "normal": 0xA8A77A, "fire": 0xEE8130, "water": 0x6390F0, "electric": 0xF7D02C, "grass": 0x7AC74C,
    "ice": 0x96D9D6, "fighting": 0xC22E28, "poison": 0xA33EA1, "ground": 0xE2BF65, "flying": 0xA98FF3,
    "psychic": 0xF95587, "bug": 0xA6B91A, "rock": 0xB6A136, "ghost": 0x735797, "dragon": 0x6F35FC,
    "dark": 0x705746, "steel": 0xB7B7CE, "fairy": 0xD685AD,
}


def iv_table(ivs):
    """Tabela monoespaçada 'Atributo | IV'. Valores None aparecem como '—'."""
    lines = ["Atributo".ljust(18) + "IV".rjust(3)]
    for s in STATS:
        v = ivs.get(s)
        lines.append(STAT_LABELS[s].ljust(18) + ("—" if v is None else str(v)).rjust(3))
    return "```\n" + "\n".join(lines) + "\n```"


def ev_summary(evs, ruleset=DEFAULT_RULESET):
    total = sum(evs.values())
    if total == 0:
        return "EVs: 0 em todos"
    parts = ", ".join(f"{STAT_SHORT[s]} {evs[s]}" for s in STATS if evs[s] > 0)
    return f"EVs: {parts} ({total}/{ruleset.max_ev_total})"


def build_sheet_embed(poke):
    sp = poke["species"]
    ruleset = RULESETS.get(poke.get("ruleset"), DEFAULT_RULESET)
    stats = calculate_stats(sp["base"], poke["ivs"], poke["evs"], poke["level"], poke["nature"], ruleset)

    types = " / ".join(f"**{TYPE_PT.get(t, t.title())}**" for t in sp["types"])
    dex = f"#{sp['dex']:04d} · " if sp.get("dex") else ""
    embed = discord.Embed(
        title=sp["display_name"],
        description=(
            f"{dex}**Nv. {poke['level']}**\n"
            f"Tipos: {types}\n"
            f"Treinador: <@{poke['owner_id']}> · ID `{poke['id']}`"
        ),
        color=TYPE_COLOR.get(sp["types"][0], 0x5865F2) if sp["types"] else 0x5865F2,
    )
    if sp.get("artwork"):
        embed.set_thumbnail(url=sp["artwork"])

    # grade 2 colunas x 3 linhas (o campo vazio força a quebra de linha a cada 2 stats)
    for i, s in enumerate(STATS):
        embed.add_field(name=f"{STAT_EMOJI[s]} {STAT_LABELS[s]}", value=f"**{stats[s]}**", inline=True)
        if i % 2 == 1:
            embed.add_field(name="\u200b", value="\u200b", inline=True)

    embed.add_field(
        name="🎲 IVs (valores individuais — não são os stats finais)",
        value=iv_table(poke["ivs"]),
        inline=False,
    )
    embed.set_footer(
        text=f"Nv. {poke['level']} • Natureza: {nature_label(poke['nature'])} • "
             f"{ev_summary(poke['evs'], ruleset)} • Regras: {ruleset.label}"
    )
    return embed


def build_session_embed(sess):
    sp = sess["species"]
    rolls, asg = sess["rolls"], sess["assignment"]
    shown = {s: (rolls[asg[s]] if asg.get(s) is not None else None) for s in STATS}
    dice = "  ".join(f"`{i + 1}º: {v}`" for i, v in enumerate(rolls))
    embed = discord.Embed(
        title=f"🎲 IVs de {sp['display_name']} (Nv. {sess['level']})",
        description=(
            f"Treinador: <@{sess['owner_id']}>\n"
            f"**Dados rolados:** {dice}\n\n"
            "Cada dado vale para **um** atributo, na ordem que você quiser."
        ),
        color=0x5865F2,
    )
    embed.add_field(name="Distribuição atual", value=iv_table(shown), inline=False)
    cur = sess.get("current_stat")
    step = (
        f"Atribuindo a: {STAT_LABELS[cur]}. Escolha o dado no 2º menu."
        if cur else "Todos atribuídos! Toque em Confirmar." if all(v is not None for v in shown.values())
        else "Escolha um atributo no 1º menu."
    )
    embed.set_footer(text=step)
    return embed
