"""Gera o GIF de evolução (estilo jogo) com Pillow. Sem dependência de Discord.

Sequência: forma antiga -> fica branca -> silhuetas alternando cada vez mais rápido
(com brilho) -> clarão -> nova forma surge com faíscas.
"""
import io
import math
import random

from PIL import Image, ImageChops, ImageDraw, ImageFilter

SIZE = 320


def _load_sprite(raw, size):
    """Abre o PNG, recorta as margens vazias e centraliza num quadrado transparente."""
    img = Image.open(io.BytesIO(raw)).convert("RGBA")
    bbox = img.getchannel("A").getbbox()
    if bbox is None:
        raise ValueError("Imagem sem conteúdo visível.")
    img = img.crop(bbox)
    target = int(size * 0.68)
    scale = target / max(img.size)
    img = img.resize((max(1, round(img.width * scale)), max(1, round(img.height * scale))), Image.LANCZOS)
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    layer.paste(img, ((size - img.width) // 2, (size - img.height) // 2), img)
    return layer


def _scaled(layer, factor):
    if abs(factor - 1) < 0.001:
        return layer
    size = layer.size[0]
    w = max(1, round(size * factor))
    big = layer.resize((w, w), Image.LANCZOS)
    out = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    out.paste(big, ((size - w) // 2, (size - w) // 2), big)
    return out


def _tint_white(layer, t):
    """Mistura o sprite com branco (t=0 normal, t=1 silhueta branca), mantendo o contorno."""
    alpha = layer.getchannel("A")
    rgb = Image.blend(layer.convert("RGB"), Image.new("RGB", layer.size, (255, 255, 255)), t)
    rgb.putalpha(alpha)
    return rgb


def _glow(layer, strength):
    """Halo branco difuso ao redor do contorno do sprite."""
    if strength <= 0:
        return None
    mask = layer.getchannel("A").filter(ImageFilter.GaussianBlur(14))
    mask = mask.point(lambda v: min(255, int(v * 1.6 * strength)))
    halo = Image.new("RGBA", layer.size, (255, 255, 255, 0))
    halo.putalpha(mask)
    return halo


def _star(draw, cx, cy, r, alpha):
    pts = [(cx, cy - r), (cx + r * .25, cy - r * .25), (cx + r, cy), (cx + r * .25, cy + r * .25),
           (cx, cy + r), (cx - r * .25, cy + r * .25), (cx - r, cy), (cx - r * .25, cy - r * .25)]
    draw.polygon(pts, fill=(255, 250, 200, alpha))


def _sparkles(size, t, rng_seed):
    """Faíscas que sobem e somem; t vai de 0 a 1."""
    layer = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    if t >= 1:
        return layer
    draw = ImageDraw.Draw(layer)
    rng = random.Random(rng_seed)
    for _ in range(14):
        cx = rng.uniform(.15, .85) * size
        cy0 = rng.uniform(.3, .9) * size
        r = rng.uniform(.015, .04) * size * (1 - t * .5)
        cy = cy0 - t * rng.uniform(.05, .2) * size
        _star(draw, cx, cy, r, int(255 * (1 - t)))
    return layer


def _background(size, accent):
    dark = (24, 25, 36)
    tint = tuple(int(d * .82 + a * .18) for d, a in zip(dark, accent))
    return Image.new("RGBA", (size, size), tint + (255,))


def _compose(bg, sprite, glow=None, sparkle=None, flash=0.0):
    frame = bg.copy()
    if glow is not None:
        frame = Image.alpha_composite(frame, glow)
    frame = Image.alpha_composite(frame, sprite)
    if sparkle is not None:
        frame = Image.alpha_composite(frame, sparkle)
    if flash > 0:
        white = Image.new("RGBA", frame.size, (255, 255, 255, int(255 * flash)))
        frame = Image.alpha_composite(frame, white)
    return frame


def render_evolution_gif(old_png, new_png, accent=(88, 101, 242), size=SIZE):
    """old_png/new_png: bytes das imagens. Retorna os bytes do GIF animado."""
    old = _load_sprite(old_png, size)
    new = _load_sprite(new_png, size)
    bg = _background(size, accent)
    frames = []  # (imagem RGBA, duração em ms)

    frames.append((_compose(bg, old), 900))                                   # forma antiga

    for t in (.25, .5, .75, 1.0):                                              # fica branca
        frames.append((_compose(bg, _tint_white(old, t), _glow(old, t * .6)), 90))

    # silhuetas alternando: o intervalo entre trocas vai encurtando
    holds = [5, 5, 4, 4, 3, 3, 2, 2, 1, 1, 1, 1, 1, 1]
    showing_new = False
    n = 0
    for i, hold in enumerate(holds):
        base = new if showing_new else old
        for _ in range(hold if hold > 1 else 1):
            pulse = 1 + .05 * math.sin(n * .9)
            sil = _tint_white(_scaled(base, pulse), 1.0)
            strength = .7 + .3 * min(1, i / len(holds))
            frames.append((_compose(bg, sil, _glow(sil, strength)), 70 if hold > 1 else 55))
            n += 1
        showing_new = not showing_new

    for f in (.5, 1.0, .6):                                                    # clarão
        frames.append((_compose(bg, _tint_white(new, 1.0), None, None, f), 70))

    for k, t in enumerate((1.0, .75, .5, .3, .12, 0.0)):                      # nova forma surge
        spark = _sparkles(size, k / 6, 7)
        frames.append((_compose(bg, _tint_white(new, t), _glow(new, t * .5), spark), 100))

    frames.append((_compose(bg, new), 3000))                                   # pose final

    pal = [f.convert("RGB").quantize(colors=160, dither=0) for f, _ in frames]
    buf = io.BytesIO()
    pal[0].save(
        buf, format="GIF", save_all=True, append_images=pal[1:],
        duration=[d for _, d in frames], loop=0, disposal=2,
    )
    return buf.getvalue()
