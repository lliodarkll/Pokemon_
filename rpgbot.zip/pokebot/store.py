"""Persistência em SQLite: fichas, sessões de IV, configurações e cache da API."""
import json
import os
import sqlite3
from datetime import datetime, timedelta, timezone

from . import personagem as pers
from .calculator import zero_evs


class StoreError(Exception):
    pass


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    guild_id INTEGER, key TEXT, value TEXT, PRIMARY KEY (guild_id, key));
CREATE TABLE IF NOT EXISTS api_cache (
    key TEXT PRIMARY KEY, value TEXT NOT NULL, fetched_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS pokemon (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL, owner_id INTEGER NOT NULL,
    species TEXT NOT NULL,            -- JSON: snapshot dos dados da espécie
    level INTEGER NOT NULL,
    nature TEXT NOT NULL DEFAULT 'Hardy',
    ivs TEXT NOT NULL, evs TEXT NOT NULL,
    ruleset TEXT NOT NULL DEFAULT 'gen3+',
    damage INTEGER NOT NULL DEFAULT 0,        -- dano acumulado (HP atual = HP máx - dano)
    moves TEXT NOT NULL DEFAULT '[]',         -- JSON: até 4 golpes (com PP atual)
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_pokemon_owner ON pokemon (guild_id, owner_id);
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL, owner_id INTEGER NOT NULL,
    species TEXT NOT NULL, level INTEGER NOT NULL,
    rolls TEXT NOT NULL, assignment TEXT NOT NULL, current_stat TEXT,
    status TEXT NOT NULL DEFAULT 'pending',   -- pending | finalized | cancelled
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS personagens (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    guild_id INTEGER NOT NULL, owner_id INTEGER NOT NULL,
    nome TEXT NOT NULL COLLATE NOCASE,
    attrs TEXT NOT NULL DEFAULT '{}',         -- JSON: atributo -> pontos fixos
    extras TEXT NOT NULL DEFAULT '{}',        -- JSON: campos livres (vindos das fichas antigas)
    created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    UNIQUE (guild_id, nome));
CREATE INDEX IF NOT EXISTS idx_personagens_owner ON personagens (guild_id, owner_id);
"""

_JSON_POKE = ("species", "ivs", "evs", "moves")
_EDITABLE = {"level", "nature", "ivs", "evs", "species", "damage", "moves"}


class Store:
    def __init__(self, path="pokemon.db"):
        self.db = sqlite3.connect(path)
        self.db.row_factory = sqlite3.Row
        self.db.executescript(SCHEMA)
        self._migrate()
        self.db.commit()

    def _migrate(self):
        """Bancos criados antes do modo batalha ganham as colunas novas, sem perder dados."""
        cols = {r["name"] for r in self.db.execute("PRAGMA table_info(pokemon)")}
        if "damage" not in cols:
            self.db.execute("ALTER TABLE pokemon ADD COLUMN damage INTEGER NOT NULL DEFAULT 0")
        if "moves" not in cols:
            self.db.execute("ALTER TABLE pokemon ADD COLUMN moves TEXT NOT NULL DEFAULT '[]'")

    # ----- configurações -----
    def get_setting(self, guild_id, key, default=None):
        row = self.db.execute(
            "SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key)
        ).fetchone()
        return row["value"] if row else default

    def set_setting(self, guild_id, key, value):
        with self.db:
            self.db.execute(
                "INSERT INTO settings (guild_id, key, value) VALUES (?,?,?) "
                "ON CONFLICT(guild_id, key) DO UPDATE SET value=excluded.value",
                (guild_id, key, value),
            )

    # ----- cache da API -----
    def cache_get(self, key, max_age_days=30):
        row = self.db.execute("SELECT value, fetched_at FROM api_cache WHERE key=?", (key,)).fetchone()
        if not row:
            return None
        age = datetime.now(timezone.utc) - datetime.fromisoformat(row["fetched_at"])
        if age > timedelta(days=max_age_days):
            return None
        return json.loads(row["value"])

    def cache_put(self, key, value):
        with self.db:
            self.db.execute(
                "INSERT INTO api_cache (key, value, fetched_at) VALUES (?,?,?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, fetched_at=excluded.fetched_at",
                (key, json.dumps(value), _now()),
            )

    # ----- Pokémon -----
    @staticmethod
    def _poke(row):
        if row is None:
            return None
        d = dict(row)
        for k in _JSON_POKE:
            d[k] = json.loads(d[k])
        return d

    def get_pokemon(self, guild_id, pid):
        row = self.db.execute(
            "SELECT * FROM pokemon WHERE guild_id=? AND id=?", (guild_id, pid)
        ).fetchone()
        return self._poke(row)

    def list_pokemon(self, guild_id, owner_id=None):
        if owner_id is None:
            rows = self.db.execute("SELECT * FROM pokemon WHERE guild_id=? ORDER BY id", (guild_id,))
        else:
            rows = self.db.execute(
                "SELECT * FROM pokemon WHERE guild_id=? AND owner_id=? ORDER BY id", (guild_id, owner_id)
            )
        return [self._poke(r) for r in rows.fetchall()]

    def find_by_name(self, guild_id, owner_id, name):
        wanted = name.strip().lower()
        return [
            p for p in self.list_pokemon(guild_id, owner_id)
            if p["species"]["display_name"].lower() == wanted
        ]

    def update_pokemon(self, guild_id, pid, **fields):
        if not fields or not set(fields) <= _EDITABLE:
            raise StoreError("Campos inválidos para atualização.")
        sets, values = [], []
        for k, v in fields.items():
            sets.append(f"{k}=?")
            values.append(json.dumps(v) if k in _JSON_POKE else v)
        with self.db:
            cur = self.db.execute(
                f"UPDATE pokemon SET {', '.join(sets)}, updated_at=? WHERE guild_id=? AND id=?",
                (*values, _now(), guild_id, pid),
            )
        if cur.rowcount == 0:
            raise StoreError("Pokémon não encontrado.")

    def delete_pokemon(self, guild_id, pid):
        with self.db:
            self.db.execute("DELETE FROM pokemon WHERE guild_id=? AND id=?", (guild_id, pid))

    # ----- personagens (ficha do jogador) -----
    @staticmethod
    def _pers(row):
        if row is None:
            return None
        d = dict(row)
        d["attrs"] = pers.completar(json.loads(d["attrs"]))
        d["extras"] = json.loads(d["extras"])
        return d

    def create_personagem(self, guild_id, owner_id, nome, attrs=None, extras=None):
        nome = " ".join(str(nome).split())
        if not 1 <= len(nome) <= 40:
            raise StoreError("O nome do personagem precisa ter de 1 a 40 caracteres.")
        now = _now()
        try:
            with self.db:
                cur = self.db.execute(
                    "INSERT INTO personagens (guild_id, owner_id, nome, attrs, extras, created_at, updated_at) "
                    "VALUES (?,?,?,?,?,?,?)",
                    (guild_id, owner_id, nome, json.dumps(pers.completar(attrs)),
                     json.dumps(extras or {}, ensure_ascii=False), now, now),
                )
        except sqlite3.IntegrityError:
            raise StoreError("Já existe um personagem com esse nome.") from None
        return cur.lastrowid

    def get_personagem(self, guild_id, pid):
        return self._pers(self.db.execute(
            "SELECT * FROM personagens WHERE guild_id=? AND id=?", (guild_id, pid)).fetchone())

    def find_personagem(self, guild_id, nome):
        return self._pers(self.db.execute(
            "SELECT * FROM personagens WHERE guild_id=? AND nome=?", (guild_id, nome.strip())).fetchone())

    def list_personagens(self, guild_id, owner_id=None):
        if owner_id is None:
            rows = self.db.execute("SELECT * FROM personagens WHERE guild_id=? ORDER BY nome", (guild_id,))
        else:
            rows = self.db.execute(
                "SELECT * FROM personagens WHERE guild_id=? AND owner_id=? ORDER BY nome", (guild_id, owner_id))
        return [self._pers(r) for r in rows.fetchall()]

    def update_personagem(self, guild_id, pid, nome=None, attrs=None, extras=None):
        sets, values = [], []
        if nome is not None:
            nome = " ".join(str(nome).split())
            if not 1 <= len(nome) <= 40:
                raise StoreError("O nome do personagem precisa ter de 1 a 40 caracteres.")
            sets.append("nome=?")
            values.append(nome)
        if attrs is not None:
            sets.append("attrs=?")
            values.append(json.dumps(pers.completar(attrs)))
        if extras is not None:
            sets.append("extras=?")
            values.append(json.dumps(extras, ensure_ascii=False))
        if not sets:
            return
        try:
            with self.db:
                cur = self.db.execute(
                    f"UPDATE personagens SET {', '.join(sets)}, updated_at=? WHERE guild_id=? AND id=?",
                    (*values, _now(), guild_id, pid),
                )
        except sqlite3.IntegrityError:
            raise StoreError("Já existe um personagem com esse nome.") from None
        if cur.rowcount == 0:
            raise StoreError("Personagem não encontrado.")

    def delete_personagem(self, guild_id, pid):
        with self.db:
            self.db.execute("DELETE FROM personagens WHERE guild_id=? AND id=?", (guild_id, pid))

    def migrate_old_fichas(self, path="fichas.db"):
        """Copia as fichas genéricas antigas (fichas.db) para personagens, uma única vez.

        Campos com nome de atributo (Força, Destreza...) viram pontos; o resto vai para 'extras'.
        O arquivo antigo não é alterado. Retorna quantas fichas foram copiadas.
        """
        if self.get_setting(0, "fichas_migradas") or not os.path.isfile(path):
            return 0
        old = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            has = old.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='fichas'").fetchone()
            rows = old.execute("SELECT guild_id, owner_id, nome, dados FROM fichas").fetchall() if has else []
        finally:
            old.close()
        copied = 0
        for guild_id, owner_id, nome, dados in rows:
            try:
                dados = json.loads(dados or "{}")
            except ValueError:
                dados = {}
            attrs, extras = {}, {}
            for campo, valor in dados.items():
                chave = pers.chave_atributo(campo)
                if chave and isinstance(valor, int) and not isinstance(valor, bool) \
                        and pers.PONTOS_MIN <= valor <= pers.PONTOS_MAX:
                    attrs[chave] = valor
                else:
                    extras[campo] = valor
            try:
                self.create_personagem(guild_id, owner_id, nome, attrs, extras)
                copied += 1
            except StoreError:
                pass  # nome inválido ou repetido: ignora essa ficha
        self.set_setting(0, "fichas_migradas", "1")
        return copied

    # ----- sessões de IV -----
    @staticmethod
    def _session(row):
        if row is None:
            return None
        d = dict(row)
        for k in ("species", "rolls", "assignment"):
            d[k] = json.loads(d[k])
        return d

    def create_session(self, guild_id, owner_id, species, level, rolls):
        now = _now()
        assignment = {}  # preenchido pelo chamador via save_session
        with self.db:
            cur = self.db.execute(
                "INSERT INTO sessions (guild_id, owner_id, species, level, rolls, assignment, "
                "current_stat, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (guild_id, owner_id, json.dumps(species), level, json.dumps(rolls),
                 json.dumps(assignment), None, now, now),
            )
        return cur.lastrowid

    def get_session(self, sid):
        return self._session(self.db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone())

    def get_pending_session(self, guild_id, owner_id):
        row = self.db.execute(
            "SELECT * FROM sessions WHERE guild_id=? AND owner_id=? AND status='pending' "
            "ORDER BY id DESC LIMIT 1",
            (guild_id, owner_id),
        ).fetchone()
        return self._session(row)

    def save_session(self, sid, assignment, current_stat):
        with self.db:
            self.db.execute(
                "UPDATE sessions SET assignment=?, current_stat=?, updated_at=? "
                "WHERE id=? AND status='pending'",
                (json.dumps(assignment), current_stat, _now(), sid),
            )

    def set_session_status(self, sid, status):
        with self.db:
            self.db.execute(
                "UPDATE sessions SET status=?, updated_at=? WHERE id=?", (status, _now(), sid)
            )

    def finalize_session(self, sid, ivs, nature="Hardy", evs=None):
        """Cria o Pokémon e fecha a sessão numa única transação (protege contra clique duplo)."""
        evs = evs or zero_evs()
        with self.db:
            row = self.db.execute("SELECT * FROM sessions WHERE id=?", (sid,)).fetchone()
            if row is None or row["status"] != "pending":
                raise StoreError("Esta sessão não está mais pendente.")
            now = _now()
            cur = self.db.execute(
                "INSERT INTO pokemon (guild_id, owner_id, species, level, nature, ivs, evs, "
                "created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (row["guild_id"], row["owner_id"], row["species"], row["level"], nature,
                 json.dumps(ivs), json.dumps(evs), now, now),
            )
            self.db.execute(
                "UPDATE sessions SET status='finalized', updated_at=? WHERE id=?", (now, sid)
            )
            return cur.lastrowid
