"""Camada Discord: comandos /pokémon e /pokédex e as telas interativas."""
import asyncio
import io
import logging
from typing import Optional

import discord
from discord import app_commands

from . import calculator as calc
from . import iv_session as ivs
from .pokeapi import (
    ApiUnavailable, PokeApiClient, PokeApiError, Species, SpeciesNotFound, available_evolutions, newly_ready,
    normalize_name,
)
from .sheet import TYPE_COLOR, build_session_embed, build_sheet_embed
from .store import Store, StoreError

log = logging.getLogger("pokebot")

# Nomes dos comandos. O Discord exige minúsculas (não existe "P" maiúsculo); acentos são permitidos.
# Se alguém não achar os comandos digitando sem acento, troque ACENTOS para False e reinicie o bot.
ACENTOS = True
NOME_GRUPO = "pok\u00e9mon" if ACENTOS else "pokemon"
NOME_DEX = "pok\u00e9dex" if ACENTOS else "pokedex"


def parse_int(text, lo, hi):
    t = str(text).strip()
    if not (t.isascii() and t.isdigit()) or not lo <= int(t) <= hi:
        raise ValueError(f"Digite um número inteiro de {lo} a {hi}.")
    return int(t)


class Module:
    def __init__(self, db_path):
        self.store = Store(db_path)
        self.api = PokeApiClient(self.store)
        self._names_task = None

    def names_task(self):
        t = self._names_task
        if t is None or (t.done() and (t.cancelled() or t.exception())):
            t = self._names_task = asyncio.ensure_future(self.api.list_names())
        return t

    async def build_evolution_file(self, old_sp, new_sp):
        """Gera o GIF da evolução. Retorna discord.File, ou None se faltar imagem."""
        if not old_sp.get("artwork") or not new_sp.get("artwork"):
            return None
        old_img = await self.api.get_image(old_sp["artwork"])
        new_img = await self.api.get_image(new_sp["artwork"])
        from .evolution_gif import render_evolution_gif  # import tardio: Pillow é opcional

        color = TYPE_COLOR.get(new_sp["types"][0], 0x5865F2) if new_sp["types"] else 0x5865F2
        accent = ((color >> 16) & 255, (color >> 8) & 255, color & 255)
        data = await asyncio.get_running_loop().run_in_executor(
            None, render_evolution_gif, old_img, new_img, accent
        )
        return discord.File(io.BytesIO(data), filename="evolucao.gif")

    async def offer_evolution(self, inter, poke, old_level):
        """Após subir de nível: se um requisito de nível foi cruzado, pergunta se quer evoluir."""
        if poke["level"] <= old_level:
            return
        try:
            evos = await self.api.get_evolutions(Species.from_dict(poke["species"]))
            ready = newly_ready(evos, old_level, poke["level"])
            if ready:
                await inter.followup.send(
                    embed=evolution_prompt_embed(poke, ready), view=EvolveView(self, poke, ready)
                )
        except Exception:  # nunca atrapalha a edição de nível
            log.exception("não foi possível checar evolução")

    async def propose_species_change(self, inter, poke, especie):
        """Prévia + confirmação da troca de espécie. A interação precisa ter sido adiada (defer)."""
        try:
            sp = await self.api.get_species(especie)
        except PokeApiError as e:
            return await inter.followup.send(api_error_message(e))
        if sp.identifier == poke["species"]["identifier"]:
            return await inter.followup.send("Esse Pokémon já é dessa espécie.")
        old = calc.calculate_stats(poke["species"]["base"], poke["ivs"], poke["evs"], poke["level"], poke["nature"])
        new = calc.calculate_stats(sp.base, poke["ivs"], poke["evs"], poke["level"], poke["nature"])
        preview = discord.Embed(
            title=f"Trocar {poke['species']['display_name']} → {sp.display_name}?",
            description="Nível, IVs, EVs e natureza serão mantidos.\n\n" + stat_diff(old, new),
            color=0xFEE75C,
        )
        pid, gid = poke["id"], poke["guild_id"]

        async def do(i):
            self.store.update_pokemon(gid, pid, species=sp.to_dict())
            fresh = self.store.get_pokemon(gid, pid)
            await i.response.edit_message(
                content="✅ Pokémon atualizado.", embed=build_sheet_embed(fresh), view=PanelView(self, fresh)
            )

        await inter.followup.send(embed=preview, view=ConfirmView(inter.user.id, do))


def is_admin(inter):
    return inter.user.guild_permissions.manage_guild


def can_edit(inter, owner_id):
    return inter.user.id == owner_id or is_admin(inter)


def api_error_message(e):
    if isinstance(e, SpeciesNotFound):
        return (f"Não encontrei a espécie **{e}**. Escolha uma das sugestões do campo "
                "(formas alternativas aparecem como `vulpix-alola`, `charizard-mega-x`...).")
    if isinstance(e, ApiUnavailable):
        return "A PokéAPI está fora do ar ou lenta agora. Tente de novo em instantes."
    return "Recebi dados inesperados da PokéAPI. Tente outra espécie ou mais tarde."


# ---------- telas interativas ----------
class ConfirmView(discord.ui.View):
    """Confirmação explícita (Confirmar / Cancelar) restrita a quem abriu."""

    def __init__(self, owner_id, action):
        super().__init__(timeout=120)
        self.owner_id = owner_id
        self.action = action

    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message("Só quem pediu pode confirmar.", ephemeral=True)
            return False
        return True

    @discord.ui.button(label="Confirmar", style=discord.ButtonStyle.success)
    async def confirm(self, interaction, button):
        self.stop()
        try:
            await self.action(interaction)
        except (StoreError, calc.CalcError) as e:
            await interaction.response.edit_message(content=f"❌ {e}", embed=None, view=None)

    @discord.ui.button(label="Cancelar", style=discord.ButtonStyle.secondary)
    async def cancel(self, interaction, button):
        self.stop()
        await interaction.response.edit_message(content="Cancelado. Nada foi alterado.", embed=None, view=None)


class IVView(discord.ui.View):
    """Distribuição de IVs: 1º menu = atributo, 2º menu = dado, botões de ação.
    Todo o estado fica no banco; a view só desenha. Se o bot reiniciar, use /pokédex."""

    def __init__(self, mod, sess):
        super().__init__(timeout=900)
        self.mod = mod
        self.sid = sess["id"]
        self.owner_id = sess["owner_id"]
        rolls, asg, cur = sess["rolls"], sess["assignment"], sess.get("current_stat")

        stat_opts = [
            discord.SelectOption(
                label=f"{calc.STAT_LABELS[s]}: {rolls[asg[s]] if asg.get(s) is not None else '—'}",
                value=s, default=(s == cur),
            )
            for s in calc.STATS
        ]
        sel_stat = discord.ui.Select(placeholder="1) Escolha o atributo", options=stat_opts, row=0)
        sel_stat.callback = self.on_stat
        self.add_item(sel_stat)

        roll_opts = []
        if cur:
            own = asg.get(cur)
            free = ivs.unassigned_rolls(asg, len(rolls))
            if own is not None:
                free = sorted(set(free) | {own})
            roll_opts = [
                discord.SelectOption(label=f"Dado {i + 1}: {rolls[i]}", value=str(i), default=(i == own))
                for i in free
            ]
        disabled = not roll_opts
        if disabled:
            roll_opts = [discord.SelectOption(label="—", value="none")]
        sel_roll = discord.ui.Select(
            placeholder="2) Escolha o dado", options=roll_opts, row=1, disabled=disabled
        )
        sel_roll.callback = self.on_roll
        self.add_item(sel_roll)

        complete = all(asg.get(s) is not None for s in calc.STATS)
        btn_ok = discord.ui.Button(label="Confirmar", style=discord.ButtonStyle.success, row=2, disabled=not complete)
        btn_clear = discord.ui.Button(label="Limpar", style=discord.ButtonStyle.secondary, row=2)
        btn_cancel = discord.ui.Button(label="Cancelar", style=discord.ButtonStyle.danger, row=2)
        btn_ok.callback, btn_clear.callback, btn_cancel.callback = self.on_confirm, self.on_clear, self.on_cancel
        for b in (btn_ok, btn_clear, btn_cancel):
            self.add_item(b)

    # -- util --
    async def interaction_check(self, interaction):
        if interaction.user.id != self.owner_id:
            await interaction.response.send_message(
                "Esta distribuição de IVs pertence a outro jogador.", ephemeral=True
            )
            return False
        return True

    def _pending(self):
        s = self.mod.store.get_session(self.sid)
        return s if s and s["status"] == "pending" else None

    async def _inactive(self, interaction):
        self.stop()
        await interaction.response.edit_message(content="Esta sessão não está mais ativa.", embed=None, view=None)

    async def _redraw(self, interaction):
        sess = self.mod.store.get_session(self.sid)
        self.stop()
        await interaction.response.edit_message(
            embed=build_session_embed(sess), view=IVView(self.mod, sess)
        )

    # -- callbacks --
    async def on_stat(self, interaction):
        sess = self._pending()
        if not sess:
            return await self._inactive(interaction)
        stat = interaction.data["values"][0]
        if stat not in calc.STATS:
            return await interaction.response.send_message("Atributo inválido.", ephemeral=True)
        self.mod.store.save_session(self.sid, sess["assignment"], stat)
        await self._redraw(interaction)

    async def on_roll(self, interaction):
        sess = self._pending()
        if not sess:
            return await self._inactive(interaction)
        stat = sess.get("current_stat")
        if not stat:
            return await interaction.response.send_message("Escolha um atributo primeiro.", ephemeral=True)
        try:
            idx = int(interaction.data["values"][0])
            new = ivs.assign(sess["assignment"], stat, idx, len(sess["rolls"]))
        except (ValueError, ivs.SessionError) as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        self.mod.store.save_session(self.sid, new, ivs.next_open_stat(new))
        await self._redraw(interaction)

    async def on_clear(self, interaction):
        if not self._pending():
            return await self._inactive(interaction)
        self.mod.store.save_session(self.sid, ivs.empty_assignment(), None)
        await self._redraw(interaction)

    async def on_cancel(self, interaction):
        if not self._pending():
            return await self._inactive(interaction)
        self.mod.store.set_session_status(self.sid, "cancelled")
        self.stop()
        await interaction.response.edit_message(content="Sessão de IVs cancelada.", embed=None, view=None)

    async def on_confirm(self, interaction):
        sess = self._pending()
        if not sess:
            return await self._inactive(interaction)
        try:  # revalidação no servidor: nunca confie só nos botões
            final_ivs = ivs.validate_complete(sess["rolls"], sess["assignment"])
            pid = self.mod.store.finalize_session(self.sid, final_ivs)
        except (ivs.SessionError, calc.CalcError, StoreError) as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        self.stop()
        poke = self.mod.store.get_pokemon(sess["guild_id"], pid)
        await interaction.response.edit_message(
            content=f"✅ Ficha criada! Use `/{NOME_DEX}` para ajustar nível, natureza, EVs e espécie.",
            embed=build_sheet_embed(poke), view=None
        )


def pretty(name):
    return str(name).replace("-", " ").title()


def stat_diff(old, new):
    lines = []
    for st in calc.STATS:
        d = new[st] - old[st]
        lines.append(f"{calc.STAT_LABELS[st]}: {old[st]} → **{new[st]}** ({d:+d})")
    return "\n".join(lines)


def evolution_prompt_embed(poke, options):
    lines = "\n".join(f"• **{pretty(o.target)}** — {o.requirement}" for o in options)
    e = discord.Embed(
        title=f"✨ {poke['species']['display_name']} pode evoluir!",
        description=f"{lines}\n\nNível, IVs, EVs e natureza são mantidos. Evoluir agora?",
        color=0xFEE75C,
    )
    if poke["species"].get("artwork"):
        e.set_thumbnail(url=poke["species"]["artwork"])
    return e


class EvolveView(discord.ui.View):
    """Pergunta 'Evoluir?' e, se confirmado, toca o GIF e troca a espécie."""

    def __init__(self, mod, poke, options, choice=None):
        super().__init__(timeout=600)
        self.mod = mod
        self.pid, self.guild_id, self.owner_id = poke["id"], poke["guild_id"], poke["owner_id"]
        self.from_id = poke["species"]["identifier"]
        self.poke, self.option_list = poke, options
        self.options = {o.target: o for o in options}
        self.choice = choice if choice in self.options else options[0].target
        row = 0
        if len(options) > 1:
            sel = discord.ui.Select(
                placeholder="Evoluir para...", row=0,
                options=[
                    discord.SelectOption(label=pretty(o.target)[:100], description=o.requirement[:100],
                                         value=o.target, default=(o.target == self.choice))
                    for o in options[:25]
                ],
            )
            sel.callback = self.on_select
            self.add_item(sel)
            row = 1
        go = discord.ui.Button(label="✨ Evoluir", style=discord.ButtonStyle.success, row=row)
        no = discord.ui.Button(label="Agora não", style=discord.ButtonStyle.secondary, row=row)
        go.callback, no.callback = self.on_go, self.on_cancel
        self.add_item(go)
        self.add_item(no)

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id or interaction.user.guild_permissions.manage_guild:
            return True
        await interaction.response.send_message("Só o dono do Pokémon ou o mestre decide a evolução.", ephemeral=True)
        return False

    async def on_select(self, interaction):
        value = interaction.data["values"][0]
        if value not in self.options:
            return await interaction.response.send_message("Opção inválida.", ephemeral=True)
        self.stop()
        await interaction.response.edit_message(
            view=EvolveView(self.mod, self.poke, self.option_list, choice=value)
        )

    async def on_cancel(self, interaction):
        self.stop()
        await interaction.response.edit_message(content="Evolução adiada. Nada foi alterado.", embed=None, view=None)

    async def on_go(self, interaction):
        store = self.mod.store
        poke = store.get_pokemon(self.guild_id, self.pid)
        if not poke or poke["species"]["identifier"] != self.from_id:
            self.stop()
            return await interaction.response.edit_message(
                content=f"Esse Pokémon mudou desde o pedido. Use `/{NOME_GRUPO} evoluir` de novo.", embed=None, view=None
            )
        evo = self.options[self.choice]
        self.stop()
        await interaction.response.edit_message(
            content=f"✨ **{poke['species']['display_name']} está evoluindo...**", embed=None, view=None
        )
        try:
            new_sp = await self.mod.api.get_species(evo.target)
        except PokeApiError as e:
            return await interaction.edit_original_response(content=api_error_message(e))

        file = None
        try:
            file = await self.mod.build_evolution_file(poke["species"], new_sp.to_dict())
        except Exception:  # a evolução vale mesmo sem animação
            log.exception("falha ao gerar o GIF de evolução")

        fresh = store.get_pokemon(self.guild_id, self.pid)
        if not fresh or fresh["species"]["identifier"] != self.from_id:
            return await interaction.edit_original_response(content="Esse Pokémon mudou; evolução cancelada.")
        old_stats = calc.calculate_stats(fresh["species"]["base"], fresh["ivs"], fresh["evs"], fresh["level"], fresh["nature"])
        store.update_pokemon(self.guild_id, self.pid, species=new_sp.to_dict())
        new_poke = store.get_pokemon(self.guild_id, self.pid)
        new_stats = calc.calculate_stats(new_sp.base, new_poke["ivs"], new_poke["evs"], new_poke["level"], new_poke["nature"])

        embed = discord.Embed(
            title=f"✨ {fresh['species']['display_name']} evoluiu para {new_sp.display_name}!",
            description=stat_diff(old_stats, new_stats),
            color=TYPE_COLOR.get(new_sp.types[0], 0x5865F2) if new_sp.types else 0x5865F2,
        )
        kwargs = {"content": None, "embed": embed}
        if file:
            embed.set_image(url="attachment://evolucao.gif")
            kwargs["attachments"] = [file]
        await interaction.edit_original_response(**kwargs)
        await interaction.followup.send(embed=build_sheet_embed(new_poke))


class NumberModal(discord.ui.Modal):
    """Janela para digitar um número (nível, EV...)."""

    def __init__(self, title, label, lo, hi, on_value):
        super().__init__(title=title)
        self.lo, self.hi, self.on_value = lo, hi, on_value
        self.field = discord.ui.TextInput(label=label, placeholder=f"{lo} a {hi}", required=True, max_length=4)
        self.add_item(self.field)

    async def on_submit(self, interaction):
        try:
            n = parse_int(self.field.value, self.lo, self.hi)
        except ValueError as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        await self.on_value(interaction, n)


class TextModal(discord.ui.Modal):
    """Janela para digitar um texto (nome da espécie)."""

    def __init__(self, title, label, placeholder, on_value):
        super().__init__(title=title)
        self.on_value = on_value
        self.field = discord.ui.TextInput(label=label, placeholder=placeholder, required=True, max_length=60)
        self.add_item(self.field)

    async def on_submit(self, interaction):
        await self.on_value(interaction, self.field.value.strip())


class PanelView(discord.ui.View):
    """Painel do Pokédex: natureza (menu), nível (botões ou digitar), EVs e espécie."""

    def __init__(self, mod, poke, mode="main", ev_stat="hp"):
        super().__init__(timeout=900)
        self.mod = mod
        self.pid, self.guild_id, self.owner_id = poke["id"], poke["guild_id"], poke["owner_id"]
        self.mode, self.ev_stat = mode, ev_stat
        if mode == "evs":
            self._build_evs(poke)
        else:
            self._build_main(poke)

    # -- montagem --
    def _btn(self, label, style, row, cb, disabled=False, emoji=None):
        b = discord.ui.Button(label=label, style=style, row=row, disabled=disabled, emoji=emoji)
        b.callback = cb
        self.add_item(b)

    def _build_main(self, poke):
        sel = discord.ui.Select(
            placeholder="Natureza", row=0,
            options=[
                discord.SelectOption(label=calc.nature_label(n)[:100], value=n, default=(n == poke["nature"]))
                for n in calc.NATURES
            ],
        )
        sel.callback = self.on_nature
        self.add_item(sel)
        lvl = poke["level"]
        for d in (-10, -1, 1, 10):
            blocked = (d < 0 and lvl <= 1) or (d > 0 and lvl >= 100)
            self._btn(f"{d:+d}", discord.ButtonStyle.danger if d < 0 else discord.ButtonStyle.success,
                      1, self._level_cb(d), disabled=blocked)
        self._btn("Nível…", discord.ButtonStyle.secondary, 1, self.on_level_modal, emoji="🔢")
        self._btn("Espécie…", discord.ButtonStyle.primary, 2, self.on_species_modal, emoji="🔁")
        self._btn("EVs", discord.ButtonStyle.primary, 2, self.on_open_evs, emoji="📊")
        self._btn("Fechar", discord.ButtonStyle.secondary, 2, self.on_close, emoji="✖️")

    def _build_evs(self, poke):
        evs = poke["evs"]
        sel = discord.ui.Select(
            placeholder="Atributo", row=0,
            options=[
                discord.SelectOption(label=f"{calc.STAT_LABELS[s]}: {evs[s]} EV", value=s, default=(s == self.ev_stat))
                for s in calc.STATS
            ],
        )
        sel.callback = self.on_ev_stat
        self.add_item(sel)
        for d in (-10, -4, 4, 10):
            self._btn(f"{d:+d}", discord.ButtonStyle.danger if d < 0 else discord.ButtonStyle.success,
                      1, self._ev_cb(d))
        self._btn("Valor…", discord.ButtonStyle.secondary, 1, self.on_ev_modal, emoji="🔢")
        self._btn("Zerar tudo", discord.ButtonStyle.danger, 2, self.on_ev_zero, emoji="🧹")
        self._btn("Voltar", discord.ButtonStyle.secondary, 2, self.on_back, emoji="↩️")

    # -- util --
    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id or interaction.user.guild_permissions.manage_guild:
            return True
        await interaction.response.send_message("Só o dono do Pokémon ou o mestre mexe neste painel.", ephemeral=True)
        return False

    def _load(self):
        return self.mod.store.get_pokemon(self.guild_id, self.pid)

    async def _gone(self, interaction):
        self.stop()
        await interaction.response.edit_message(content="Esse Pokémon não existe mais.", embed=None, view=None)

    async def _redraw(self, interaction, poke, mode=None, ev_stat=None):
        self.stop()
        await interaction.response.edit_message(
            content=None, embed=build_sheet_embed(poke),
            view=PanelView(self.mod, poke, mode or self.mode, ev_stat or self.ev_stat),
        )

    # -- natureza --
    async def on_nature(self, interaction):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        try:
            nat = calc.canonical_nature(interaction.data["values"][0])
        except calc.CalcError as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        self.mod.store.update_pokemon(self.guild_id, self.pid, nature=nat)
        await self._redraw(interaction, self._load())

    # -- nível --
    def _level_cb(self, delta):
        async def cb(interaction):
            poke = self._load()
            if not poke:
                return await self._gone(interaction)
            await self.set_level(interaction, poke, poke["level"] + delta)
        return cb

    async def set_level(self, interaction, poke, new_level):
        new_level = max(1, min(100, new_level))
        old = poke["level"]
        if new_level != old:
            self.mod.store.update_pokemon(self.guild_id, self.pid, level=new_level)
        fresh = self._load()
        await self._redraw(interaction, fresh)
        await self.mod.offer_evolution(interaction, fresh, old)

    async def apply_level(self, interaction, n):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        await self.set_level(interaction, poke, n)

    async def on_level_modal(self, interaction):
        await interaction.response.send_modal(
            NumberModal("Nível", "Novo nível (1–100)", 1, 100, self.apply_level)
        )

    # -- espécie --
    async def apply_species(self, interaction, text):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        await interaction.response.defer()
        await self.mod.propose_species_change(interaction, poke, text)

    async def on_species_modal(self, interaction):
        await interaction.response.send_modal(
            TextModal("Trocar espécie", "Nome da espécie", "ex.: lampent ou vulpix-alola", self.apply_species)
        )

    # -- EVs --
    async def on_open_evs(self, interaction):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        await self._redraw(interaction, poke, mode="evs")

    async def on_back(self, interaction):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        await self._redraw(interaction, poke, mode="main")

    async def on_ev_stat(self, interaction):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        stat = interaction.data["values"][0]
        if stat not in calc.STATS:
            return await interaction.response.send_message("Atributo inválido.", ephemeral=True)
        await self._redraw(interaction, poke, mode="evs", ev_stat=stat)

    async def set_ev(self, interaction, poke, value):
        value = max(0, min(252, value))
        new = {**poke["evs"], self.ev_stat: value}
        try:
            calc.validate_evs(new)
        except calc.CalcError as e:
            return await interaction.response.send_message(f"❌ {e}", ephemeral=True)
        self.mod.store.update_pokemon(self.guild_id, self.pid, evs=new)
        await self._redraw(interaction, self._load(), mode="evs")

    def _ev_cb(self, delta):
        async def cb(interaction):
            poke = self._load()
            if not poke:
                return await self._gone(interaction)
            await self.set_ev(interaction, poke, poke["evs"][self.ev_stat] + delta)
        return cb

    async def apply_ev(self, interaction, n):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        await self.set_ev(interaction, poke, n)

    async def on_ev_modal(self, interaction):
        label = f"EV de {calc.STAT_LABELS[self.ev_stat]} (0–252)"
        await interaction.response.send_modal(NumberModal("EVs", label, 0, 252, self.apply_ev))

    async def on_ev_zero(self, interaction):
        poke = self._load()
        if not poke:
            return await self._gone(interaction)
        self.mod.store.update_pokemon(self.guild_id, self.pid, evs=calc.zero_evs())
        await self._redraw(interaction, self._load(), mode="evs")

    async def on_close(self, interaction):
        poke = self._load()
        self.stop()
        if not poke:
            return await interaction.response.edit_message(content="Esse Pokémon não existe mais.", embed=None, view=None)
        await interaction.response.edit_message(content=None, embed=build_sheet_embed(poke), view=None)


class PickView(discord.ui.View):
    """Quando o jogador tem vários Pokémon e não disse qual: menu para escolher."""

    def __init__(self, mod, owner_id, pokes):
        super().__init__(timeout=300)
        self.mod, self.owner_id = mod, owner_id
        sel = discord.ui.Select(
            placeholder="Escolha o Pokémon",
            options=[
                discord.SelectOption(
                    label=f"{p['species']['display_name']} Nv.{p['level']} (#{p['id']})"[:100], value=str(p["id"])
                )
                for p in pokes[:25]
            ],
        )
        sel.callback = self.on_pick
        self.add_item(sel)

    async def interaction_check(self, interaction):
        if interaction.user.id == self.owner_id:
            return True
        await interaction.response.send_message("Este menu é de outro jogador.", ephemeral=True)
        return False

    async def on_pick(self, interaction):
        value = interaction.data["values"][0]
        poke = self.mod.store.get_pokemon(interaction.guild_id, int(value)) if value.isdigit() else None
        if not poke or poke["owner_id"] != self.owner_id:
            return await interaction.response.send_message("Pokémon inválido.", ephemeral=True)
        self.stop()
        await interaction.response.edit_message(
            content=None, embed=build_sheet_embed(poke), view=PanelView(self.mod, poke)
        )


# ---------- registro dos comandos ----------
def register(tree, db_path="pokemon.db"):
    mod = Module(db_path)
    store = mod.store
    group = app_commands.Group(name=NOME_GRUPO, description="Fichas Pokémon", guild_only=True)

    async def species_ac(inter, current):
        try:
            names = await asyncio.wait_for(asyncio.shield(mod.names_task()), timeout=2.5)
        except Exception:
            return []
        q = normalize_name(current)
        hits = [n for n in names if n.startswith(q)] + [n for n in names if q in n and not n.startswith(q)]
        return [app_commands.Choice(name=n, value=n) for n in hits[:25]]

    async def poke_ac(inter, current):
        admin = is_admin(inter)
        rows = store.list_pokemon(inter.guild_id, None if admin else inter.user.id)
        q, out = current.lower(), []
        for p in rows:
            label = f"{p['species']['display_name']} Nv.{p['level']} (#{p['id']})"
            if admin and p["owner_id"] != inter.user.id:
                m = inter.guild.get_member(p["owner_id"])
                if m:
                    label += f" — {m.display_name}"
            if q in label.lower():
                out.append(app_commands.Choice(name=label[:100], value=str(p["id"])))
        return out[:25]

    async def nature_ac(inter, current):
        q = current.lower()
        return [
            app_commands.Choice(name=calc.nature_label(n)[:100], value=n)
            for n in calc.NATURES if q in n.lower()
        ][:25]

    async def resolve(inter, ident):
        p = None
        if ident.isdigit():
            p = store.get_pokemon(inter.guild_id, int(ident))
        else:
            found = store.find_by_name(inter.guild_id, inter.user.id, ident)
            p = found[0] if len(found) == 1 else None
        if not p:
            await inter.response.send_message(
                "Pokémon não encontrado. Escolha um da lista de sugestões.", ephemeral=True
            )
        return p

    async def deny(inter):
        await inter.response.send_message("Você só pode editar os seus próprios Pokémon.", ephemeral=True)

    # ----- criar / retomar / cancelar -----
    @group.command(name="criar", description="Cria um Pokémon, rola os 6 IVs e começa a distribuição")
    @app_commands.describe(especie="Espécie (escolha na lista)", nivel="Nível inicial (1–100)")
    @app_commands.autocomplete(especie=species_ac)
    async def criar(inter: discord.Interaction, especie: str, nivel: app_commands.Range[int, 1, 100] = 5):
        if store.get_pending_session(inter.guild_id, inter.user.id):
            return await inter.response.send_message(
                "Você já tem uma distribuição de IVs em andamento. "
                f"Use `/{NOME_DEX}` para continuar ou `/{NOME_GRUPO} cancelar` para descartar.",
                ephemeral=True,
            )
        await inter.response.defer()
        try:
            sp = await mod.api.get_species(especie)
        except PokeApiError as e:
            return await inter.followup.send(api_error_message(e))
        except Exception:
            log.exception("erro inesperado ao buscar espécie")
            return await inter.followup.send("Erro inesperado ao buscar a espécie.")
        try:
            dice = store.get_setting(inter.guild_id, "dice", ivs.DEFAULT_DICE)
            rolls = ivs.roll_ivs(dice)
        except ivs.SessionError:  # configuração antiga inválida: volta ao padrão
            rolls = ivs.roll_ivs(ivs.DEFAULT_DICE)
        sid = store.create_session(inter.guild_id, inter.user.id, sp.to_dict(), nivel, rolls)
        store.save_session(sid, ivs.empty_assignment(), "hp")
        sess = store.get_session(sid)
        await inter.followup.send(embed=build_session_embed(sess), view=IVView(mod, sess))

    @group.command(name="cancelar", description="Descarta a sua distribuição de IVs em andamento")
    async def cancelar(inter: discord.Interaction):
        sess = store.get_pending_session(inter.guild_id, inter.user.id)
        if not sess:
            return await inter.response.send_message("Você não tem distribuição pendente.", ephemeral=True)
        store.set_session_status(sess["id"], "cancelled")
        await inter.response.send_message("Distribuição de IVs cancelada.", ephemeral=True)

    # ----- consulta -----
    @group.command(name="ver", description="Mostra a ficha de um Pokémon")
    @app_commands.autocomplete(pokemon=poke_ac)
    async def ver(inter: discord.Interaction, pokemon: str):
        p = await resolve(inter, pokemon)
        if p:
            await inter.response.send_message(embed=build_sheet_embed(p))

    @group.command(name="listar", description="Lista os Pokémon do servidor")
    async def listar(inter: discord.Interaction):
        rows = store.list_pokemon(inter.guild_id)
        if not rows:
            return await inter.response.send_message("Nenhum Pokémon ainda.")
        lines = [f"`#{p['id']}` **{p['species']['display_name']}** Nv.{p['level']} — <@{p['owner_id']}>"
                 for p in rows]
        text = "\n".join(lines)
        if len(text) > 1900:
            text = text[:1900].rsplit("\n", 1)[0] + "\n…"
        await inter.response.send_message(text, allowed_mentions=discord.AllowedMentions.none())

    @group.command(name="apagar", description="Apaga um Pokémon (pede confirmação)")
    @app_commands.autocomplete(pokemon=poke_ac)
    async def apagar(inter: discord.Interaction, pokemon: str):
        p = await resolve(inter, pokemon)
        if not p:
            return
        if not can_edit(inter, p["owner_id"]):
            return await deny(inter)

        async def do(i):
            store.delete_pokemon(inter.guild_id, p["id"])
            await i.response.edit_message(content="🗑️ Pokémon apagado.", embed=None, view=None)

        await inter.response.send_message(
            f"Apagar **{p['species']['display_name']}** (#{p['id']})? Isso não tem volta.",
            view=ConfirmView(inter.user.id, do),
        )

    @group.command(name="evoluir", description="Evolui um Pokémon (por nível; item/troca só com o mestre)")
    @app_commands.describe(pokemon="Qual Pokémon", para="Só se houver mais de uma evolução possível")
    @app_commands.autocomplete(pokemon=poke_ac)
    async def evoluir(inter: discord.Interaction, pokemon: str, para: Optional[str] = None):
        p = await resolve(inter, pokemon)
        if not p:
            return
        if not can_edit(inter, p["owner_id"]):
            return await deny(inter)
        await inter.response.defer()
        try:
            evos = await mod.api.get_evolutions(Species.from_dict(p["species"]))
        except PokeApiError as e:
            return await inter.followup.send(api_error_message(e))
        name = p["species"]["display_name"]
        if not evos:
            return await inter.followup.send(f"**{name}** não tem evolução (é a forma final).")
        admin = is_admin(inter)
        options = available_evolutions(evos, p["level"], admin)
        if para:
            wanted = normalize_name(para)
            options = [o for o in options if o.target == wanted]
        if not options:
            lines = "\n".join(f"• **{pretty(e.target)}** — {e.requirement}" for e in evos)
            extra = "" if admin else "\nEvoluções por item, troca ou condição especial dependem do mestre (Gerenciar Servidor)."
            return await inter.followup.send(
                f"**{name}** (Nv. {p['level']}) ainda não pode evoluir agora. Possibilidades:\n{lines}{extra}"
            )
        await inter.followup.send(embed=evolution_prompt_embed(p, options), view=EvolveView(mod, p, options))

    # ----- admin / ajuda -----
    @group.command(name="config_dados", description="(Admin) Vê ou define a rolagem dos IVs")
    @app_commands.describe(expressao="Ex: 1d32-1 (padrão). Vazio = só mostrar a atual")
    async def config_dados(inter: discord.Interaction, expressao: Optional[str] = None):
        current = store.get_setting(inter.guild_id, "dice", ivs.DEFAULT_DICE)
        if expressao is None:
            return await inter.response.send_message(f"Rolagem atual dos IVs: `{current}`", ephemeral=True)
        if not is_admin(inter):
            return await inter.response.send_message(
                "Só quem tem a permissão Gerenciar Servidor pode mudar isso.", ephemeral=True
            )
        try:
            spec = ivs.parse_dice(expressao)
            ivs.validate_dice_for_ivs(spec)
        except ivs.SessionError as e:
            return await inter.response.send_message(f"❌ {e}", ephemeral=True)
        store.set_setting(inter.guild_id, "dice", spec.text)
        await inter.response.send_message(
            f"Rolagem dos IVs agora é `{spec.text}` (resultados de {spec.minimum} a {spec.maximum}).",
            ephemeral=True,
        )

    @group.command(name="ajuda", description="Lista todos os comandos e como usar")
    async def ajuda(inter: discord.Interaction):
        g, d = NOME_GRUPO, NOME_DEX
        e = discord.Embed(title="📖 Ajuda — todos os comandos", color=0xEE8130)
        e.add_field(name="🆕 Criar um Pokémon", inline=False, value=(
            f"`/{g} criar` espécie + nível → o bot rola **6 IVs** (padrão `1d32-1`, de 0 a 31).\n"
            "**1º menu** = atributo, **2º menu** = dado. Um dado por atributo, em qualquer ordem. "
            "Com os 6 preenchidos, toque em **Confirmar**.\n"
            f"`/{g} cancelar` descarta a distribuição pendente."))
        e.add_field(name=f"🧭 /{d} — painel de edição", inline=False, value=(
            f"`/{d}` sem nada: continua a distribuição de IVs pendente, ou abre o painel do seu Pokémon "
            "(se tiver vários, pede para escolher).\n"
            "No painel: **menu** de natureza · **−10 −1 +1 +10** ou **Nível…** (digitar) · "
            "**Espécie…** (digitar, com confirmação) · **EVs** (menu do atributo, botões ou digitar).\n"
            f"Atalho digitando: `/{d} pokemon nivel especie natureza` (todos opcionais; "
            "a espécie sempre pede confirmação). Os IVs não mudam depois de confirmados."))
        e.add_field(name="✨ Evolução", inline=False, value=(
            f"Ao subir de nível pelo `/{d}`, se o requisito for atingido o bot pergunta se quer evoluir (com animação).\n"
            f"`/{g} evoluir` faz o mesmo manualmente; evoluções por item/troca precisam do mestre."))
        e.add_field(name="🔎 Consultar e gerenciar", inline=False, value=(
            f"`/{g} ver` mostra a ficha · `/{g} listar` lista os Pokémon do servidor · "
            f"`/{g} apagar` apaga (com confirmação)."))
        e.add_field(name="🛠️ Mestre", inline=False, value=(
            f"`/{g} config_dados` muda a rolagem dos IVs (ex.: `2d16-2`). "
            "Quem tem **Gerenciar Servidor** edita qualquer Pokémon."))
        e.add_field(name="📝 Ficha do personagem", inline=False, value=(
            "`/ficha` abre a ficha do seu personagem (nome novo cria; sem ficha, pede o nome). "
            "Botões: **Atributos** (menu + `-5 -1 +1 +5` ou **Valor…**) · **Campo extra…** (ex.: HP) · "
            "**Renomear…** · **Apagar**.\n"
            "Atributos: Força, Destreza, Vigor, Inteligência, Sintonia e Afinidade (pontos fixos, 0–99)."))
        e.add_field(name="🎲 Rolagens", inline=False, value=(
            "`/for` `/des` `/vig` `/int` `/sin` `/afi` rolam **d20 + pontos** do atributo "
            "(campo opcional **bonus** para modificadores da cena; o mestre pode rolar por outro personagem).\n"
            "`/rolar` rola dados livres (ex.: `d20`, `2d6+3`)."))
        e.set_footer(text="Cálculo: fórmulas oficiais da série principal (EVs 0 e natureza neutra por padrão).")
        await inter.response.send_message(embed=e, ephemeral=True)

    @app_commands.command(name=NOME_DEX, description="Painel do seu Pokémon: nível, natureza, EVs e espécie")
    @app_commands.describe(
        pokemon="Qual Pokémon (opcional se você tiver só um)",
        nivel="Novo nível (1–100)",
        especie="Nova espécie (pede confirmação)",
        natureza="Nova natureza",
    )
    @app_commands.autocomplete(pokemon=poke_ac, especie=species_ac, natureza=nature_ac)
    @app_commands.guild_only()
    async def pokedex(
        inter: discord.Interaction,
        pokemon: Optional[str] = None,
        nivel: Optional[app_commands.Range[int, 1, 100]] = None,
        especie: Optional[str] = None,
        natureza: Optional[str] = None,
    ):
        sem_params = pokemon is None and nivel is None and especie is None and natureza is None
        if sem_params:  # antigo "retomar": distribuição de IVs pendente tem prioridade
            sess = store.get_pending_session(inter.guild_id, inter.user.id)
            if sess:
                return await inter.response.send_message(
                    content="📋 Você tem uma distribuição de IVs pendente. Continue por aqui:",
                    embed=build_session_embed(sess), view=IVView(mod, sess),
                )
        if pokemon:
            p = await resolve(inter, pokemon)
            if not p:
                return
        else:
            own = store.list_pokemon(inter.guild_id, inter.user.id)
            if not own:
                return await inter.response.send_message(
                    f"Você ainda não tem Pokémon. Use `/{NOME_GRUPO} criar`.", ephemeral=True
                )
            if len(own) == 1:
                p = own[0]
            elif not sem_params:
                return await inter.response.send_message(
                    "Você tem mais de um Pokémon: informe qual no campo **pokemon**.", ephemeral=True
                )
            else:
                return await inter.response.send_message("Escolha o Pokémon:", view=PickView(mod, inter.user.id, own))
        if not can_edit(inter, p["owner_id"]):
            return await deny(inter)

        old_level = p["level"]
        changes = {}
        if natureza:
            try:
                changes["nature"] = calc.canonical_nature(natureza)
            except calc.CalcError as e:
                return await inter.response.send_message(f"❌ {e}", ephemeral=True)
        if nivel is not None:
            changes["level"] = nivel
        if changes:
            store.update_pokemon(inter.guild_id, p["id"], **changes)
            p = store.get_pokemon(inter.guild_id, p["id"])
        if especie:
            await inter.response.defer()
            return await mod.propose_species_change(inter, p, especie)
        await inter.response.send_message(embed=build_sheet_embed(p), view=PanelView(mod, p))
        if nivel is not None:
            await mod.offer_evolution(inter, p, old_level)

    tree.add_command(group)
    tree.add_command(pokedex)
    return mod
