"""Módulo Pokémon do bot de fichas."""
