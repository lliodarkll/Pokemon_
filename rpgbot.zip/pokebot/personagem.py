"""Atributos do personagem e rolagens d20 (lógica pura: sem Discord, sem rede)."""
import random
import unicodedata

# chave interna, nome, abreviação (nome do comando), emoji
ATRIBUTOS = (
    ("forca", "Força", "for", "💪"),
    ("destreza", "Destreza", "des", "🎯"),
    ("vigor", "Vigor", "vig", "🛡️"),
    ("inteligencia", "Inteligência", "int", "🧠"),
    ("sintonia", "Sintonia", "sin", "🔮"),
    ("afinidade", "Afinidade", "afi", "🤝"),
)
CHAVES = tuple(a[0] for a in ATRIBUTOS)
NOMES = {a[0]: a[1] for a in ATRIBUTOS}
ABREV = {a[0]: a[2] for a in ATRIBUTOS}
EMOJIS = {a[0]: a[3] for a in ATRIBUTOS}

PONTOS_MIN, PONTOS_MAX = 0, 99
MAX_PERSONAGENS_POR_JOGADOR = 1  # o mestre (Gerenciar Servidor) não tem limite


class PersonagemError(Exception):
    pass


def normalizar(texto):
    """minúsculas, sem acento e sem espaços nas pontas ('Força ' -> 'forca')."""
    t = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode()
    return t.strip().lower()


def chave_atributo(texto):
    """Aceita nome completo, sem acento ou abreviação ('Força', 'forca', 'for'). None se não for atributo."""
    t = normalizar(texto)
    for chave, nome, abrev, _ in ATRIBUTOS:
        if t in (chave, abrev, normalizar(nome)):
            return chave
    return None


def atributos_padrao():
    return {c: 0 for c in CHAVES}


def completar(attrs):
    """Garante as 6 chaves (pontos inválidos viram 0) sem perder nada do que já existe."""
    out = atributos_padrao()
    for c in CHAVES:
        v = (attrs or {}).get(c, 0)
        out[c] = v if isinstance(v, int) and not isinstance(v, bool) else 0
    return out


def validar_pontos(valor):
    try:
        n = int(str(valor).strip())
    except ValueError:
        raise PersonagemError(f"Digite um número inteiro de {PONTOS_MIN} a {PONTOS_MAX}.") from None
    if not PONTOS_MIN <= n <= PONTOS_MAX:
        raise PersonagemError(f"Os pontos vão de {PONTOS_MIN} a {PONTOS_MAX}.")
    return n


def rolar_atributo(pontos, bonus=0, rng=random):
    """d20 + pontos do atributo + bônus extra da cena."""
    dado = rng.randint(1, 20)
    total = dado + pontos + bonus
    crit = "nat20" if dado == 20 else "nat1" if dado == 1 else None
    return {"dado": dado, "pontos": pontos, "bonus": bonus, "total": total, "crit": crit}


def texto_rolagem(nome_personagem, chave, r):
    """Mensagem do resultado, ex.: 🎲 **Ash** — 💪 Força: d20 (13) + 4 + 2 = **19**"""
    partes = f"d20 ({r['dado']}) + {r['pontos']}"
    if r["bonus"]:
        partes += f" {'+' if r['bonus'] > 0 else '−'} {abs(r['bonus'])}"
    linha = f"🎲 **{nome_personagem}** — {EMOJIS[chave]} {NOMES[chave]}: {partes} = **{r['total']}**"
    if r["crit"] == "nat20":
        linha += "\n🌟 **20 natural!** Crítico!"
    elif r["crit"] == "nat1":
        linha += "\n💀 **1 natural!** Falha crítica!"
    return linha
