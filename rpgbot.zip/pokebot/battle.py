"""Lógica pura de combate: HP, barra de HP, golpes e PP (sem Discord, sem rede)."""
import copy
import math
import random
import re
from dataclasses import dataclass

MAX_SLOTS = 4


class BattleError(ValueError):
    """Ação de combate inválida."""


# ---------- HP ----------
def hp_current(max_hp, damage):
    """O banco guarda o DANO acumulado; assim, ao subir de nível o HP atual sobe junto (como nos jogos)."""
    return max(0, max_hp - max(0, damage))


def change_hp(damage, max_hp, amount):
    """amount > 0 cura, < 0 dá dano. Retorna o novo dano acumulado, limitado a 0..max_hp."""
    return min(max_hp, max(0, damage - amount))


def hp_bar(current, maximum, segments=10):
    if maximum <= 0 or current <= 0:
        return "⬛" * segments
    current = min(current, maximum)
    filled = max(1, math.ceil(current / maximum * segments))
    ratio = current / maximum
    color = "🟩" if ratio > 0.5 else "🟨" if ratio > 0.2 else "🟥"
    return color * filled + "⬛" * (segments - filled)


def parse_amount(text):
    t = str(text).strip()
    if not re.fullmatch(r"\d{1,4}", t) or int(t) < 1:
        raise BattleError("Digite um número inteiro de 1 a 9999.")
    return int(t)


# ---------- golpes ----------
def normalize_moves(moves):
    """Sempre 4 posições; vazio = None."""
    out = [None] * MAX_SLOTS
    for i, m in enumerate((moves or [])[:MAX_SLOTS]):
        out[i] = m or None
    return out


def new_slot(move):
    """move = pokeapi.Move.to_dict()."""
    return {
        "id": move["identifier"], "name": move["display_name"], "type": move["type"],
        "category": move["category"], "power": move["power"], "accuracy": move["accuracy"],
        "pp": move["pp"], "pp_max": move["pp"],
    }


def _index(slot):
    if isinstance(slot, bool) or not isinstance(slot, int) or not 1 <= slot <= MAX_SLOTS:
        raise BattleError(f"O slot deve ser de 1 a {MAX_SLOTS}.")
    return slot - 1


def add_move(moves, slot_dict, slot=None):
    """Retorna (novos_golpes, golpe_substituído|None). Sem slot, usa o primeiro vazio."""
    moves = normalize_moves(moves)
    if any(m and m["id"] == slot_dict["id"] for m in moves):
        raise BattleError(f"Esse Pokémon já conhece {slot_dict['name']}.")
    if slot is None:
        idx = next((i for i, m in enumerate(moves) if m is None), None)
        if idx is None:
            raise BattleError("Os 4 slots estão cheios. Informe o slot (1–4) que deseja substituir.")
    else:
        idx = _index(slot)
    old = moves[idx]
    moves[idx] = slot_dict
    return moves, old


def remove_move(moves, slot):
    moves = normalize_moves(moves)
    idx = _index(slot)
    if moves[idx] is None:
        raise BattleError(f"O slot {slot} já está vazio.")
    removed, moves[idx] = moves[idx], None
    return moves, removed


@dataclass
class MoveUse:
    move: dict
    hit: bool
    roll: int | None   # None = golpe que não testa precisão
    pp_left: int
    pp_max: int


def use_move(moves, slot, rng=None):
    """Gasta 1 PP e testa a precisão com d100. Retorna (novos_golpes, MoveUse)."""
    moves = copy.deepcopy(normalize_moves(moves))
    idx = _index(slot)
    m = moves[idx]
    if m is None:
        raise BattleError(f"O slot {slot} está vazio.")
    if m["pp"] <= 0:
        raise BattleError(f"{m['name']} está sem PP. Use Descanso para recuperar.")
    m["pp"] -= 1
    if m["accuracy"] is None:
        roll, hit = None, True
    else:
        roll = (rng or random.SystemRandom()).randint(1, 100)
        hit = roll <= m["accuracy"]
    return moves, MoveUse(copy.deepcopy(m), hit, roll, m["pp"], m["pp_max"])


def rest_moves(moves):
    moves = copy.deepcopy(normalize_moves(moves))
    for m in moves:
        if m:
            m["pp"] = m["pp_max"]
    return moves


def auto_moves(learnset, level, n=MAX_SLOTS):
    """Os últimos `n` golpes por nível aprendidos até `level` (como um Pokémon selvagem)."""
    cands = sorted((lv, name) for name, lv in learnset.items() if lv is not None and lv <= level)
    return [name for _, name in cands[-n:]]
