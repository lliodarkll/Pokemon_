"""
Bot base (discord.py) + comando /rolar.

A ficha do personagem (/ficha) e os atalhos de atributo (/for, /des, ...) ficam em pokebot/ficha_cmds.py.
Instalar:  pip install discord.py
Rodar:     python main.py   (com DISCORD_TOKEN no ambiente ou no bot.env)
"""
import random
import re

import discord
from discord import app_commands


class Bot(discord.Client):
    def __init__(self):
        super().__init__(intents=discord.Intents.default())
        self.tree = app_commands.CommandTree(self)

    async def setup_hook(self):
        await self.tree.sync()


bot = Bot()


# ---------- Dados ----------
@bot.tree.command(name="rolar", description="Rola dados (ex: 2d6+3, d20)")
async def rolar(inter: discord.Interaction, expressao: str):
    m = re.fullmatch(r"(\d*)d(\d+)([+-]\d+)?", expressao.replace(" ", "").lower())
    if not m:
        return await inter.response.send_message(
            "Formato inválido. Exemplos: `d20`, `2d6+3`, `4d8-1`.", ephemeral=True
        )
    qtd = int(m.group(1) or 1)
    lados = int(m.group(2))
    bonus = int(m.group(3) or 0)
    if not (1 <= qtd <= 100 and 2 <= lados <= 1000):
        return await inter.response.send_message(
            "Limites: 1–100 dados, 2–1000 lados.", ephemeral=True
        )
    rolls = [random.randint(1, lados) for _ in range(qtd)]
    total = sum(rolls) + bonus
    await inter.response.send_message(
        f"🎲 `{expressao}` → {rolls} {bonus:+d} = **{total}**"
        if bonus
        else f"🎲 `{expressao}` → {rolls} = **{total}**"
    )
